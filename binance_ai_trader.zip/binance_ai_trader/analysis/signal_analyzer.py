﻿from typing import Dict


class SignalQualityAnalyzer:
    def __init__(self):
        self.signal_history = []
        
    def evaluate_signal_quality(self, signal: Dict, tech_analysis: Dict) -> Dict:
        quality_score = 0.5
        reasons = []
        
        strength_weights = {'6': 1.0, '5': 0.8, '4': 0.6, '3': 0.4}
        signal_strength = signal['signal_type'][0]
        strength_score = strength_weights.get(signal_strength, 0.5)
        quality_score += (strength_score - 0.5) * 0.3
        reasons.append(f"Сила: {signal_strength}")
        
        tech_score = tech_analysis.get('score', 0.5)
        if ((signal['action'] == 'BUY' and tech_score > 0.6) or 
            (signal['action'] == 'SELL' and tech_score < 0.4)):
            quality_score += 0.2
            reasons.append("Совпадение с ТА")
        else:
            quality_score -= 0.1
            reasons.append("Расхождение с ТА")
        
        volatility = tech_analysis.get('volatility', 'low')
        if volatility == 'medium':
            quality_score += 0.1
            reasons.append("Оптимальная волатильность")
        elif volatility == 'high':
            quality_score -= 0.05
            reasons.append("Высокая волатильность")
        
        volume_ratio = tech_analysis.get('indicators', {}).get('volume_ratio', 1)
        if volume_ratio > 1.5:
            quality_score += 0.1
            reasons.append("Высокие объемы")
        
        if signal.get('is_fresh_signal'):
            quality_score += 0.25
            reasons.append("🔥 ФРЕШ СИГНАЛ")
        
        quality_score = max(0.1, min(0.95, quality_score))
        
        return {
            'quality_score': quality_score,
            'reasons': reasons,
            'recommended_action': 'STRONG_BUY' if quality_score > 0.8 else 
                                'BUY' if quality_score > 0.65 else
                                'NEUTRAL' if quality_score > 0.35 else
                                'SELL' if quality_score > 0.2 else 'STRONG_SELL'
        }