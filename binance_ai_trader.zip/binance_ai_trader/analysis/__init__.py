﻿# Technical analysis modules
