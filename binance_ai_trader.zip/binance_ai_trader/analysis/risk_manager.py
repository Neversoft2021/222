﻿from typing import Tuple, Dict, List
from datetime import datetime


class AdaptiveRiskManager:
    def __init__(self):
        self.volatility_cache = {}
        self.trailing_stops = {}
        self.scaling_positions = {}
        
    def calculate_adaptive_tp_sl(self, atr_percent: float, strategy: str, order_type: str = None) -> Tuple[float, float]:
        """
        Рассчитывает TP/SL с учетом типа сигнала Minerva
        """
        # 🔥 ПРИОРИТЕТ: Настройки для надежных сигналов Minerva
        if order_type and ('1.5 > 15' in order_type or '1.5 > 30' in order_type):
            return self._get_minerva_reliable_tp_sl(order_type)
        
        # Старая логика для других стратегий
        if strategy == 'scalping':
            base_tp, base_sl = 1.2, 0.6
            if atr_percent > 4.0:
                return base_tp * 1.3, base_sl * 1.4
            elif atr_percent > 2.0:
                return base_tp * 1.1, base_sl * 1.2
            return base_tp, base_sl
        else:
            base_tp, base_sl = 3.5, 1.8
            if atr_percent > 5.0:
                return base_tp * 1.4, base_sl * 1.5
            elif atr_percent > 2.5:
                return base_tp * 1.2, base_sl * 1.3
            return base_tp, base_sl
    
    def _get_minerva_reliable_tp_sl(self, order_type: str) -> Tuple[float, float]:
        """
        TP/SL для надежных сигналов Minerva (1.5>15 и 1.5>30)
        """
        if '1.5 > 15' in order_type:
            # Более агрессивный сигнал - быстрая прибыль
            print("🎯 TP/SL для 1.5>15: 3.0%/1.2%")
            return 3.0, 1.2
        elif '1.5 > 30' in order_type:
            # Менее агрессивный - большая прибыль
            print("🎯 TP/SL для 1.5>30: 4.5%/1.8%") 
            return 4.5, 1.8
        else:
            # По умолчанию для других надежных сигналов
            return 3.5, 1.5

    def calculate_position_size(self, available_margin: float, risk_per_trade: float, 
                              confidence: float, volatility: str, leverage: int) -> float:
        max_position_value = available_margin * leverage
        base_size = max_position_value * risk_per_trade
        
        confidence_multiplier = 0.5 + (confidence * 0.5)
        volatility_multiplier = {'low': 0.7, 'medium': 1.0, 'high': 0.8}.get(volatility, 1.0)
        
        position_size = base_size * confidence_multiplier * volatility_multiplier
        
        min_position = 25
        max_position = min(available_margin * leverage * 0.8, 100)
        
        return float(max(min_position, min(position_size, max_position)))

    def update_trailing_stop(self, symbol: str, current_price: float, position: Dict) -> Tuple[float, bool]:
        """
        Обновляет трейлинг-стоп для позиции
        Возвращает новый стоп-уровень и флаг нужно ли закрыть позицию
        """
        if symbol not in self.trailing_stops:
            # Инициализация трейлинг-стопа
            entry_price = position['entry_price']
            initial_sl = position['sl']
            
            if position['side'] == 'buy':
                stop_price = entry_price * (1 - initial_sl / 100)
                self.trailing_stops[symbol] = {
                    'stop_price': stop_price,
                    'highest_price': entry_price,
                    'trailing_active': False
                }
            else:
                stop_price = entry_price * (1 + initial_sl / 100)
                self.trailing_stops[symbol] = {
                    'stop_price': stop_price,
                    'lowest_price': entry_price,
                    'trailing_active': False
                }
        
        trailing_data = self.trailing_stops[symbol]
        should_close = False
        
        if position['side'] == 'buy':
            # Для LONG позиций
            if current_price > trailing_data['highest_price']:
                trailing_data['highest_price'] = current_price
                trailing_data['trailing_active'] = True
            
            if trailing_data['trailing_active']:
                # Трейлинг активирован - двигаем стоп
                new_stop = current_price * (1 - position['sl'] / 100)
                trailing_data['stop_price'] = max(trailing_data['stop_price'], new_stop)
            
            # Проверяем не достигли ли стоп-уровня
            if current_price <= trailing_data['stop_price']:
                should_close = True
                print(f"🎯 ТРЕЙЛИНГ СТОП: {symbol} - цена {current_price:.4f} <= стоп {trailing_data['stop_price']:.4f}")
                
        else:
            # Для SHORT позиций
            if current_price < trailing_data['lowest_price']:
                trailing_data['lowest_price'] = current_price
                trailing_data['trailing_active'] = True
            
            if trailing_data['trailing_active']:
                # Трейлинг активирован - двигаем стоп
                new_stop = current_price * (1 + position['sl'] / 100)
                trailing_data['stop_price'] = min(trailing_data['stop_price'], new_stop)
            
            # Проверяем не достигли ли стоп-уровня
            if current_price >= trailing_data['stop_price']:
                should_close = True
                print(f"🎯 ТРЕЙЛИНГ СТОП: {symbol} - цена {current_price:.4f} >= стоп {trailing_data['stop_price']:.4f}")
        
        return trailing_data['stop_price'], should_close

    def check_position_scaling(self, symbol: str, current_price: float, position: Dict, available_margin: float) -> Dict:
        """
        Проверяет возможность масштабирования позиции (добавления к winning trade)
        Возвращает рекомендацию по масштабированию
        """
        if symbol not in self.scaling_positions:
            self.scaling_positions[symbol] = {
                'scale_levels': [],
                'last_scale_time': None,
                'max_scales': 2  # Максимум 2 добавления к позиции
            }
        
        scaling_data = self.scaling_positions[symbol]
        entry_price = position['entry_price']
        current_pnl_percent = 0
        
        if position['side'] == 'buy':
            current_pnl_percent = (current_price - entry_price) / entry_price * 100
        else:
            current_pnl_percent = (entry_price - current_price) / entry_price * 100
        
        scaling_recommendation = {
            'should_scale': False,
            'scale_size': 0,
            'scale_reason': ''
        }
        
        # Условия для масштабирования
        if (len(scaling_data['scale_levels']) < scaling_data['max_scales'] and 
            current_pnl_percent >= 1.5 and  # Минимум +1.5% прибыли
            available_margin > position.get('position_value', 0) * 0.3):  # Достаточно маржи
            
            # Проверяем временной интервал (не чаще чем раз в 10 минут)
            current_time = datetime.now()
            if (scaling_data['last_scale_time'] is None or 
                (current_time - scaling_data['last_scale_time']).total_seconds() > 600):
                
                scaling_recommendation['should_scale'] = True
                scaling_recommendation['scale_size'] = position.get('position_value', 0) * 0.5  # 50% от исходного размера
                scaling_recommendation['scale_reason'] = f"Profit: {current_pnl_percent:.1f}%"
                
                # Добавляем уровень масштабирования
                scaling_data['scale_levels'].append({
                    'price': current_price,
                    'size': scaling_recommendation['scale_size'],
                    'time': current_time
                })
                scaling_data['last_scale_time'] = current_time
        
        return scaling_recommendation

    def cleanup_trailing_data(self, symbol: str):
        """Очищает данные трейлинг-стопа для закрытой позиции"""
        if symbol in self.trailing_stops:
            del self.trailing_stops[symbol]
        if symbol in self.scaling_positions:
            del self.scaling_positions[symbol]