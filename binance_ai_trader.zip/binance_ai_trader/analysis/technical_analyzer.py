﻿import pandas as pd
import numpy as np
import ta
from typing import Dict, List
from datetime import datetime, timedelta

from analysis.risk_manager import AdaptiveRiskManager


class AdvancedTechnicalAnalyzer:
    def __init__(self):
        self.ohlcv_cache = {}
        self.cache_timeout = 60
        self.risk_manager = AdaptiveRiskManager()
        self.correlation_cache = {}
        self.correlation_timeout = 300  # 5 минут для кэша корреляции
        
    async def analyze_trend(self, symbol: str, client, timeframe: str = '5m') -> Dict:
        try:
            cache_key = f"{symbol}_{timeframe}"
            current_time = datetime.now()
            
            if (cache_key in self.ohlcv_cache and 
                (current_time - self.ohlcv_cache[cache_key]['timestamp']).seconds < self.cache_timeout):
                return self.ohlcv_cache[cache_key]['analysis']
            
            ohlcv = client.fetch_ohlcv(symbol, timeframe, limit=100)
            if len(ohlcv) < 50:
                return {'trend': 'neutral', 'momentum': 'weak', 'score': 0.5}
            
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            
            analysis = {
                'trend': 'neutral', 'momentum': 'weak', 'volatility': 'low',
                'score': 0.5, 'indicators': {}, 'adaptive_tp_sl': {}
            }
            
            # SMA
            df['sma_20'] = ta.trend.sma_indicator(df['close'], window=20)
            df['sma_50'] = ta.trend.sma_indicator(df['close'], window=50)
            current_close = df['close'].iloc[-1]
            sma_20, sma_50 = df['sma_20'].iloc[-1], df['sma_50'].iloc[-1]
            
            if current_close > sma_20 > sma_50:
                analysis['trend'] = 'strong_bullish'
                analysis['score'] += 0.2
            elif current_close > sma_20 and sma_20 > sma_50:
                analysis['trend'] = 'bullish'
                analysis['score'] += 0.1
            elif current_close < sma_20 < sma_50:
                analysis['trend'] = 'strong_bearish'
                analysis['score'] -= 0.2
            elif current_close < sma_20 and sma_20 < sma_50:
                analysis['trend'] = 'bearish'
                analysis['score'] -= 0.1
            
            # RSI
            df['rsi'] = ta.momentum.rsi(df['close'], window=14)
            rsi = df['rsi'].iloc[-1]
            analysis['indicators']['rsi'] = rsi
            
            if rsi < 30:
                analysis['momentum'] = 'oversold'
                analysis['score'] += 0.15
            elif rsi > 70:
                analysis['momentum'] = 'overbought'
                analysis['score'] -= 0.15
            elif 40 < rsi < 60:
                analysis['momentum'] = 'neutral'
            elif rsi > 55:
                analysis['momentum'] = 'bullish'
                analysis['score'] += 0.05
            elif rsi < 45:
                analysis['momentum'] = 'bearish'
                analysis['score'] -= 0.05
            
            # MACD
            macd = ta.trend.MACD(df['close'])
            df['macd'] = macd.macd()
            df['macd_signal'] = macd.macd_signal()
            df['macd_histogram'] = macd.macd_diff()
            
            macd_current = df['macd'].iloc[-1]
            macd_signal = df['macd_signal'].iloc[-1]
            
            analysis['indicators']['macd'] = macd_current
            analysis['indicators']['macd_signal'] = macd_signal
            
            if macd_current > macd_signal and df['macd'].iloc[-2] <= df['macd_signal'].iloc[-2]:
                analysis['score'] += 0.1
            elif macd_current < macd_signal and df['macd'].iloc[-2] >= df['macd_signal'].iloc[-2]:
                analysis['score'] -= 0.1
            
            # ATR
            df['atr'] = ta.volatility.average_true_range(df['high'], df['low'], df['close'])
            atr_percent = (df['atr'].iloc[-1] / current_close) * 100
            analysis['indicators']['atr_percent'] = atr_percent
            
            if atr_percent > 3:
                analysis['volatility'] = 'high'
            elif atr_percent > 1.5:
                analysis['volatility'] = 'medium'
            else:
                analysis['volatility'] = 'low'
            
            # Volume
            volume_avg = df['volume'].tail(20).mean()
            volume_current = df['volume'].iloc[-1]
            volume_ratio = volume_current / volume_avg if volume_avg > 0 else 1
            analysis['indicators']['volume_ratio'] = volume_ratio
            
            if volume_ratio > 2.0:
                analysis['score'] += 0.1
            elif volume_ratio > 1.5:
                analysis['score'] += 0.05
            
            # Bollinger Bands
            bb = ta.volatility.BollingerBands(df['close'])
            bb_position = (current_close - bb.bollinger_lband().iloc[-1]) / (bb.bollinger_hband().iloc[-1] - bb.bollinger_lband().iloc[-1])
            analysis['indicators']['bb_position'] = bb_position
            
            if bb_position < 0.2:
                analysis['score'] += 0.1
            elif bb_position > 0.8:
                analysis['score'] -= 0.1
            
            analysis['score'] = max(0.1, min(0.9, analysis['score']))
            
            # TP/SL
            analysis['adaptive_tp_sl']['scalping'] = self.risk_manager.calculate_adaptive_tp_sl(atr_percent, 'scalping')
            analysis['adaptive_tp_sl']['main'] = self.risk_manager.calculate_adaptive_tp_sl(atr_percent, 'main')
            
            self.ohlcv_cache[cache_key] = {'analysis': analysis, 'timestamp': current_time}
            return analysis
            
        except Exception as e:
            print(f"⚠️ Ошибка ТА {symbol}: {e}")
            return {'trend': 'neutral', 'momentum': 'weak', 'score': 0.5, 'error': str(e)}

    async def analyze_correlation(self, symbol: str, open_positions: List[str], client, timeframe: str = '15m') -> Dict:
        """
        Анализирует корреляцию с уже открытыми позициями
        Возвращает уровень корреляции и рекомендацию
        """
        cache_key = f"corr_{symbol}_{'_'.join(sorted(open_positions))}"
        current_time = datetime.now()
        
        # Проверяем кэш
        if (cache_key in self.correlation_cache and 
            (current_time - self.correlation_cache[cache_key]['timestamp']).seconds < self.correlation_timeout):
            return self.correlation_cache[cache_key]['analysis']
        
        if not open_positions:
            # Нет открытых позиций - корреляция не важна
            result = {
                'max_correlation': 0,
                'highly_correlated_pairs': [],
                'recommendation': 'SAFE',
                'correlation_score': 0
            }
            self.correlation_cache[cache_key] = {'analysis': result, 'timestamp': current_time}
            return result
        
        try:
            # Получаем данные для текущего символа
            current_ohlcv = client.fetch_ohlcv(symbol, timeframe, limit=50)
            if len(current_ohlcv) < 30:
                return {'max_correlation': 0, 'highly_correlated_pairs': [], 'recommendation': 'UNKNOWN', 'correlation_score': 0}
            
            current_df = pd.DataFrame(current_ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            current_returns = current_df['close'].pct_change().dropna()
            
            max_correlation = 0
            highly_correlated_pairs = []
            
            # Анализируем корреляцию с каждой открытой позицией
            for open_symbol in open_positions:
                try:
                    open_ohlcv = client.fetch_ohlcv(open_symbol, timeframe, limit=50)
                    if len(open_ohlcv) < 30:
                        continue
                    
                    open_df = pd.DataFrame(open_ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
                    open_returns = open_df['close'].pct_change().dropna()
                    
                    # Выравниваем размеры массивов
                    min_len = min(len(current_returns), len(open_returns))
                    if min_len < 20:
                        continue
                    
                    corr = np.corrcoef(current_returns.tail(min_len), open_returns.tail(min_len))[0, 1]
                    
                    if abs(corr) > max_correlation:
                        max_correlation = abs(corr)
                    
                    if abs(corr) > 0.7:  # Высокая корреляция
                        highly_correlated_pairs.append({
                            'pair': open_symbol,
                            'correlation': corr,
                            'direction': 'POSITIVE' if corr > 0 else 'NEGATIVE'
                        })
                        
                except Exception as e:
                    print(f"⚠️ Ошибка анализа корреляции {open_symbol}: {e}")
                    continue
            
            # Формируем рекомендацию
            if max_correlation > 0.8:
                recommendation = 'AVOID'
                correlation_score = 0.1
            elif max_correlation > 0.6:
                recommendation = 'CAUTION'
                correlation_score = 0.3
            elif max_correlation > 0.4:
                recommendation = 'MODERATE'
                correlation_score = 0.6
            else:
                recommendation = 'SAFE'
                correlation_score = 0.9
            
            result = {
                'max_correlation': max_correlation,
                'highly_correlated_pairs': highly_correlated_pairs,
                'recommendation': recommendation,
                'correlation_score': correlation_score
            }
            
            self.correlation_cache[cache_key] = {'analysis': result, 'timestamp': current_time}
            return result
            
        except Exception as e:
            print(f"⚠️ Ошибка корреляционного анализа {symbol}: {e}")
            return {'max_correlation': 0, 'highly_correlated_pairs': [], 'recommendation': 'UNKNOWN', 'correlation_score': 0.5}