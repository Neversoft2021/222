﻿import asyncio
from utils.file_manager import cleanup_old_data
from core.trading_engine import TradingEngine


async def main():
    """Основная функция запуска"""
    print("🧹 Очистка данных...")
    cleanup_old_data()
    
    # Создаем и инициализируем торговый движок
    trading_engine = TradingEngine()
    
    if await trading_engine.initialize():
        print("\n" + "=" * 50)
        print("✅ СИСТЕМА ГОТОВА!")
        print(f"💰 Баланс: ${trading_engine.performance_tracker.get_stats()['current_balance']:.2f}")
        print("⚡ Адаптивная стратегия по балансу")
        print("📊 Умное управление маржой")
        print("=" * 50)
        print("⚠️ РЕАЛЬНЫЕ ДЕНЬГИ!")
        print("=" * 50)
        
        launch = input("🚀 Запустить? (y/n): ").strip().lower()
        if launch == 'y':
            await trading_engine.run()
        else:
            await trading_engine.safe_shutdown()
    else:
        print("❌ Не удалось инициализировать систему")


if __name__ == "__main__":
    asyncio.run(main())