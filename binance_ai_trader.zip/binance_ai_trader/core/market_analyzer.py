﻿import numpy as np
from typing import Dict, List
from datetime import datetime


class MarketAnalyzer:
    def __init__(self, binance_client):
        self.client = binance_client
        self.analysis = {
            'market_regime': 'neutral',
            'volatility_regime': 'normal',
            'trend_strength': 0,
            'market_sentiment': 0,
            'risk_on': True
        }

    async def analyze_market_conditions(self, pairs: List[str]):
        """Анализ текущих рыночных условий"""
        print("📊 Анализируем рыночные условия...")
        
        try:
            # Анализ волатильности
            volatility_analysis = await self._analyze_market_volatility(pairs)
            self.analysis['volatility_regime'] = volatility_analysis
            
            # Анализ тренда
            trend_analysis = await self._analyze_market_trend(pairs)
            self.analysis['trend_strength'] = trend_analysis
            
            # Определение режима рынка
            market_regime = await self._determine_market_regime()
            self.analysis['market_regime'] = market_regime
            
            # Анализ настроений
            sentiment = await self._analyze_market_sentiment(pairs)
            self.analysis['market_sentiment'] = sentiment
            
            print(f"   ✅ Режим рынка: {market_regime.upper()}")
            print(f"   ✅ Волатильность: {volatility_analysis.upper()}")
            print(f"   ✅ Сила тренда: {trend_analysis:.2f}")
            print(f"   ✅ Настроение: {sentiment:.2f}")
            
        except Exception as e:
            print(f"❌ Ошибка анализа рынка: {e}")

    async def _analyze_market_volatility(self, pairs: List[str]) -> str:
        """Анализ волатильности рынка"""
        try:
            sample_pairs = pairs[:3]
            atr_values = []
            
            for pair in sample_pairs:
                try:
                    ohlcv = await self.client.fetch_ohlcv(pair, '1h', 24)
                    if len(ohlcv) >= 14:
                        highs = [candle[2] for candle in ohlcv]
                        lows = [candle[3] for candle in ohlcv]
                        closes = [candle[4] for candle in ohlcv]
                        
                        # Расчет ATR
                        tr_values = []
                        for i in range(1, len(ohlcv)):
                            tr1 = highs[i] - lows[i]
                            tr2 = abs(highs[i] - closes[i-1])
                            tr3 = abs(lows[i] - closes[i-1])
                            tr = max(tr1, tr2, tr3)
                            tr_values.append(tr)
                        
                        atr = np.mean(tr_values[-14:]) if len(tr_values) >= 14 else 0
                        atr_percent = (atr / closes[-1]) * 100
                        atr_values.append(atr_percent)
                        
                except Exception:
                    continue
            
            if atr_values:
                avg_atr = np.mean(atr_values)
                if avg_atr < 1.0:
                    return 'low'
                elif avg_atr < 3.0:
                    return 'normal'
                else:
                    return 'high'
            
            return 'normal'
            
        except Exception:
            return 'normal'

    async def _analyze_market_trend(self, pairs: List[str]) -> float:
        """Анализ силы тренда"""
        try:
            sample_pairs = pairs[:2]
            trend_strengths = []
            
            for pair in sample_pairs:
                try:
                    ohlcv = await self.client.fetch_ohlcv(pair, '1h', 50)
                    if len(ohlcv) >= 20:
                        closes = [candle[4] for candle in ohlcv]
                        
                        # Расчет RSI
                        gains = []
                        losses = []
                        for i in range(1, len(closes)):
                            change = closes[i] - closes[i-1]
                            if change > 0:
                                gains.append(change)
                                losses.append(0)
                            else:
                                gains.append(0)
                                losses.append(abs(change))
                        
                        avg_gain = np.mean(gains[-14:]) if len(gains) >= 14 else 1
                        avg_loss = np.mean(losses[-14:]) if len(losses) >= 14 else 1
                        
                        rs = avg_gain / avg_loss if avg_loss != 0 else 1
                        rsi = 100 - (100 / (1 + rs))
                        
                        trend_strength = abs(rsi - 50) / 50
                        trend_strengths.append(trend_strength)
                        
                except Exception:
                    continue
            
            return np.mean(trend_strengths) if trend_strengths else 0.5
            
        except Exception:
            return 0.5

    async def _determine_market_regime(self) -> str:
        """Определение режима рынка"""
        volatility = self.analysis['volatility_regime']
        trend_strength = self.analysis['trend_strength']
        
        if volatility == 'high' and trend_strength > 0.7:
            return 'trending_high_vol'
        elif volatility == 'high':
            return 'ranging_high_vol'
        elif trend_strength > 0.7:
            return 'trending_low_vol'
        else:
            return 'ranging_low_vol'

    async def _analyze_market_sentiment(self, pairs: List[str]) -> float:
        """Анализ рыночных настроений"""
        try:
            sample_pairs = pairs[:5]
            price_changes = []
            
            for pair in sample_pairs:
                try:
                    ohlcv = await self.client.fetch_ohlcv(pair, '5m', 12)
                    if len(ohlcv) >= 2:
                        current_price = ohlcv[-1][4]
                        previous_price = ohlcv[0][4]
                        change = (current_price - previous_price) / previous_price
                        price_changes.append(change)
                except Exception:
                    continue
            
            if price_changes:
                avg_change = np.mean(price_changes)
                sentiment = max(-1, min(1, avg_change * 10))
                return sentiment
            
            return 0.0
            
        except Exception:
            return 0.0

    def get_analysis(self) -> Dict:
        """Возвращает текущий анализ рынка"""
        return self.analysis.copy()