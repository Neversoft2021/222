﻿from typing import Dict
from config.risk_config import BALANCE_TIERS

class BalanceAnalyzer:
    def __init__(self):
        self.tiers = BALANCE_TIERS
    
    def analyze_balance(self, balance: float) -> Dict:
        """Анализирует баланс и возвращает настройки для соответствующего уровня"""
        for tier_name, tier_config in self.tiers.items():
            if tier_config['min_balance'] <= balance < tier_config['max_balance']:
                return {
                    'tier': tier_name,
                    'max_total_positions': tier_config['max_total_positions'],
                    'max_scalping_positions': tier_config['max_scalping_positions'],
                    'max_main_positions': tier_config['max_main_positions'],
                    'scalping_leverage': tier_config['scalping_leverage'],
                    'main_leverage': tier_config['main_leverage'],
                    'scalping_min_position': tier_config['scalping_min_position'],
                    'scalping_max_position': tier_config['scalping_max_position'],
                    'scalping_recommended_position': tier_config['scalping_recommended_position'],
                    'main_min_position': tier_config['main_min_position'],
                    'main_max_position': tier_config['main_max_position'],
                    'main_recommended_position': tier_config['main_recommended_position']
                }
        
        # Если баланс очень большой, используем xlarge
        return self.tiers['xlarge'].copy()