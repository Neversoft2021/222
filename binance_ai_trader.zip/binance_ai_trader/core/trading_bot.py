﻿import asyncio
import json
from typing import Dict, List, Optional
from datetime import datetime

from integrations.binance_client import BinanceClient
from integrations.minerva_integration import RealMinervaIntegration
from analysis.technical_analyzer import AdvancedTechnicalAnalyzer
from analysis.signal_analyzer import SignalQualityAnalyzer
from analysis.risk_manager import AdaptiveRiskManager
from core.balance_manager import BalanceAnalyzer
from core.margin_manager import MarginManager
from utils.file_manager import cleanup_old_data, save_state, load_state
from config.settings import *
from config.risk_config import *


class DeepSeekBinanceAI:
    def __init__(self):
        self.client = BinanceClient(API_KEY, SECRET_KEY)
        self.is_running = False
        self.capital = 0
        self.risk_per_trade = RISK_PER_TRADE
        
        self.SCALPING_CONFIG = {}
        self.MAIN_CONFIG = {}
        self.balance_analyzer = BalanceAnalyzer()
        self.margin_manager = MarginManager()
        
        self.dynamic_pairs = []
        self.all_scanner_signals = {}
        
        self.minerva = RealMinervaIntegration(self)
        self.technical_analyzer = AdvancedTechnicalAnalyzer()
        self.risk_manager = AdaptiveRiskManager()
        self.signal_analyzer = SignalQualityAnalyzer()
        
        self.open_positions = {}
        self.closed_positions_stats = {
            'total_closed': 0,
            'profitable_trades': 0,
            'unprofitable_trades': 0,
            'total_profit': 0.0,
            'total_loss': 0.0,
            'largest_win': 0.0,
            'largest_loss': 0.0,
            'current_streak': 0,
            'best_streak': 0,
            'worst_streak': 0
        }
        self.trading_state = {
            'last_start': datetime.now().isoformat(),
            'total_trades': 0,
            'active_positions': 0,
            'scalping_pnl': 0,
            'main_pnl': 0,
            'total_pnl': 0,
            'balance': 0,
            'used_margin': 0,
            'free_margin': 0,
            'balance_tier': 'unknown',
            'strategy_settings': {}
        }
        self.last_balance_print = None

    async def initialize(self):
        print('🚀 Инициализация DeepSeek Binance AI...')
        
        try:
            print("🔧 Настраиваем Binance...")
            await self.client.initialize()
            
            print("💰 Анализируем баланс и настраиваем стратегию...")
            total_balance = await self.client.get_total_balance()
            
            if total_balance <= 0:
                print('❌ Нет средств на счете!')
                return False
            
            balance_analysis = self.balance_analyzer.analyze_balance(total_balance)
            await self._setup_strategy_based_on_balance(total_balance, balance_analysis)
            
            self.capital = total_balance
            self.trading_state['balance'] = total_balance
            self.trading_state['free_margin'] = total_balance
            self.trading_state['balance_tier'] = balance_analysis['tier']
            self.trading_state['strategy_settings'] = balance_analysis
            
            await self._validate_scalping_pairs()
            await self.recover_state()
            
            current_balance = self.trading_state.get('balance', total_balance)
            active_positions = len(self.open_positions)
            
            print(f'💰 Общий баланс системы: ${current_balance:.2f}')
            print(f'🎯 Стратегия: {balance_analysis["tier"].upper()} уровень')
            print(f'📊 Максимум позиций: {balance_analysis["max_total_positions"]}')
            print(f'🛡️ Активных позиций: {active_positions}')
            print(f'💎 Свободная маржа: ${self.trading_state.get("free_margin", current_balance):.2f}')
            
            # 🔥 ИНТЕРАКТИВНОЕ УПРАВЛЕНИЕ ПОЗИЦИЯМИ ПРИ ЗАПУСКЕ
            if active_positions > 0:
                await self._interactive_position_management()
            else:
                print("📭 Нет открытых позиций для управления")
            
            if await self.minerva.initialize():
                print("✅ Minerva готова")
            else:
                return False
            
            print(f"🎯 Финальная проверка: Баланс ${self.trading_state['balance']:.2f}")
            return True
            
        except Exception as e:
            print(f'❌ Ошибка инициализации: {e}')
            import traceback
            traceback.print_exc()
            return False

    async def _interactive_position_management(self):
        """Интерактивное управление позициями при запуске"""
        print(f'\n🎯 УПРАВЛЕНИЕ ОТКРЫТЫМИ ПОЗИЦИЯМИ')
        print('=' * 60)
        
        # Получаем актуальные цены для всех позиций
        positions_with_pnl = []
        for symbol, position in self.open_positions.items():
            try:
                ticker = self.client.fetch_ticker(symbol)
                current_price = ticker['last']
                entry_price = position['entry_price']
                position_size = position['size']
                
                if position['side'] == 'buy':
                    pnl_usdt = (current_price - entry_price) * position_size
                    pnl_percent = (current_price - entry_price) / entry_price * 100
                else:
                    pnl_usdt = (entry_price - current_price) * position_size
                    pnl_percent = (entry_price - current_price) / entry_price * 100
                
                positions_with_pnl.append({
                    'symbol': symbol,
                    'position': position,
                    'current_price': current_price,
                    'pnl_usdt': pnl_usdt,
                    'pnl_percent': pnl_percent
                })
                
            except Exception as e:
                print(f'❌ Ошибка получения цены для {symbol}: {e}')
        
        # Сортируем по убыванию PnL
        positions_with_pnl.sort(key=lambda x: x['pnl_usdt'], reverse=True)
        
        # Выводим список позиций
        print(f"📊 ОТКРЫТЫЕ ПОЗИЦИИ ({len(positions_with_pnl)}):")
        print('-' * 60)
        
        for i, pos_data in enumerate(positions_with_pnl, 1):
            symbol = pos_data['symbol']
            position = pos_data['position']
            pnl_usdt = pos_data['pnl_usdt']
            pnl_percent = pos_data['pnl_percent']
            current_price = pos_data['current_price']
            
            strategy_emoji = "⚡" if position.get('strategy') == 'scalping' else "🎯"
            direction_emoji = position.get('direction_emoji', '⚪')
            pnl_str = f"+${pnl_usdt:.2f}" if pnl_usdt > 0 else f"-${abs(pnl_usdt):.2f}"
            
            print(f"{i:2d}. {strategy_emoji}{direction_emoji} {symbol}")
            print(f"    📊 {position['side'].upper()} | Размер: ${position.get('position_value', 0):.2f}")
            print(f"    💵 Вход: {position['entry_price']:.6f} | Текущая: {current_price:.6f}")
            print(f"    📈 PnL: {pnl_percent:+.2f}% ({pnl_str})")
            print(f"    🎯 TP: {position.get('tp', 0)}% | 🛑 SL: {position.get('sl', 0)}%")
            print(f"    ⏰ Открыта: {position['timestamp'][11:16]}")
            print()
        
        # Запрос действий от пользователя
        print('🎯 ВЫБЕРИТЕ ДЕЙСТВИЕ:')
        print('   1. Закрыть ВСЕ позиции')
        print('   2. Закрыть только убыточные позиции')
        print('   3. Закрыть конкретные позиции (по номерам)')
        print('   4. ПРОДОЛЖИТЬ без изменений')
        print('   5. ОТМЕНА запуска')
        
        choice = input('\n🎯 Ваш выбор (1-5): ').strip()
        
        if choice == '1':
            print("🗑️ Закрываем ВСЕ позиции...")
            await self._close_all_real_positions()
            print("✅ Все позиции закрыты")
            
        elif choice == '2':
            print("📉 Закрываем только убыточные позиции...")
            closed_count = 0
            for pos_data in positions_with_pnl:
                if pos_data['pnl_usdt'] < 0:
                    await self.close_real_position(pos_data['symbol'], pos_data['position'])
                    closed_count += 1
            print(f"✅ Закрыто убыточных позиций: {closed_count}")
            
        elif choice == '3':
            print("🔢 Закрываем выбранные позиции...")
            numbers_input = input("Введите номера позиций через запятую (например: 1,3,5): ").strip()
            try:
                numbers = [int(num.strip()) for num in numbers_input.split(',')]
                closed_count = 0
                for num in numbers:
                    if 1 <= num <= len(positions_with_pnl):
                        pos_data = positions_with_pnl[num-1]
                        await self.close_real_position(pos_data['symbol'], pos_data['position'])
                        closed_count += 1
                    else:
                        print(f"⚠️ Неверный номер: {num}")
                print(f"✅ Закрыто выбранных позиций: {closed_count}")
            except ValueError:
                print("❌ Ошибка ввода. Используйте формат: 1,3,5")
                
        elif choice == '4':
            print("🚀 ПРОДОЛЖАЕМ без изменений позиций")
            return
            
        elif choice == '5':
            print("❌ ОТМЕНА запуска")
            await self.safe_shutdown()
            exit()
            
        else:
            print("❌ Неверный выбор. Продолжаем без изменений.")

    async def _setup_strategy_based_on_balance(self, total_balance: float, balance_analysis: Dict):
        """Настраивает стратегию на основе АДАПТИВНОГО анализа баланса"""
        
        tier = balance_analysis['tier']
        
        print(f"🎯 АДАПТИВНАЯ НАСТРОЙКА ДЛЯ БАЛАНСА ${total_balance:.2f}")
        print(f"   📊 Уровень: {tier.upper()}")
        print(f"   🎯 Всего позиций: {balance_analysis['max_total_positions']}")
        print(f"   ⚡ Скальпинг: {balance_analysis['max_scalping_positions']} поз.")
        print(f"   📈 Основная: {balance_analysis['max_main_positions']} поз.")
        
        # 🔥 СКАЛЬПИНГ КОНФИГ (агрессивный)
        self.SCALPING_CONFIG = {
            'pairs': SCALPING_PAIRS,
            'leverage': balance_analysis['scalping_leverage'],
            'max_positions': balance_analysis['max_scalping_positions'],
            'min_position_size': balance_analysis['scalping_min_position'],
            'max_position_size': balance_analysis['scalping_max_position'],
            'recommended_position_size': balance_analysis['scalping_recommended_position']
        }
        
        # 🔥 ОСНОВНАЯ СТРАТЕГИЯ (консервативная)
        self.MAIN_CONFIG = {
            'leverage': balance_analysis['main_leverage'],
            'max_positions': balance_analysis['max_main_positions'],
            'min_position_size': balance_analysis['main_min_position'],
            'max_position_size': balance_analysis['main_max_position'],
            'recommended_position_size': balance_analysis['main_recommended_position']
        }
        
        self.max_total_positions = balance_analysis['max_total_positions']
        
        # 📊 ВЫВОД ОПТИМИЗИРОВАННЫХ ПАРАМЕТРОВ
        print(f"   ⚡ Скальпинг: плечо {self.SCALPING_CONFIG['leverage']}x")
        print(f"     💰 Размеры: ${self.SCALPING_CONFIG['min_position_size']:.2f}-${self.SCALPING_CONFIG['max_position_size']:.2f}")
        
        print(f"   📈 Основная: плечо {self.MAIN_CONFIG['leverage']}x")
        print(f"     💰 Размеры: ${self.MAIN_CONFIG['min_position_size']:.2f}-${self.MAIN_CONFIG['max_position_size']:.2f}")

    async def _validate_scalping_pairs(self):
        print("🔍 Проверяем пары...")
        valid_pairs = []
        markets = self.client.load_markets()
        
        for pair in self.SCALPING_CONFIG['pairs']:
            if pair in markets and markets[pair].get('active', True):
                valid_pairs.append(pair)
                print(f"   ✅ {pair}")
            else:
                print(f"   ❌ {pair}")
        
        self.SCALPING_CONFIG['pairs'] = valid_pairs
        print(f"📊 Доступно пар: {len(valid_pairs)}")

    async def process_fresh_signals(self, signals: List[Dict]):
        print(f"🔍 Обрабатываем {len(signals)} сигналов")
        
        if not signals:
            return
        
        available_margin = await self.calculate_available_margin()
        
        if available_margin < self.SCALPING_CONFIG['min_position_size']:
            print(f"❌ Недостаточно маржи для новых позиций (минимум ${self.SCALPING_CONFIG['min_position_size']})")
            return
        
        filtered_signals = [s for s in signals if s['signal_type'] in ['6P', '6N', '5P', '5N', '4P', '4N']]
        print(f"📊 Сильных сигналов: {len(filtered_signals)}")
        
        if not filtered_signals:
            return
            
        analyzed_signals = await self._analyze_signals_with_ta(filtered_signals)
        print(f"📈 Проанализировано: {len(analyzed_signals)}")
        
        prioritized_signals = sorted(analyzed_signals, key=lambda x: x['quality_analysis']['quality_score'], reverse=True)
        await self._open_best_fresh_signals(prioritized_signals, available_margin)

    async def _analyze_signals_with_ta(self, signals: List[Dict]) -> List[Dict]:
        analyzed_signals = []
        
        for signal in signals:
            binance_pair = await self.convert_ticker_to_binance_format(signal['ticker'])
            if not binance_pair:
                continue
                
            # 🔥 ПРОВЕРЯЕМ КОРРЕЛЯЦИЮ С ОТКРЫТЫМИ ПОЗИЦИЯМИ
            open_symbols = list(self.open_positions.keys())
            correlation_analysis = await self.technical_analyzer.analyze_correlation(
                binance_pair, open_symbols, self.client
            )
            
            # Если высокая корреляция - понижаем score
            tech_analysis = await self.technical_analyzer.analyze_trend(binance_pair, self.client)
            quality_analysis = self.signal_analyzer.evaluate_signal_quality(signal, tech_analysis)
            
            # Учитываем корреляцию в confidence
            base_confidence = self._calculate_signal_confidence(signal, tech_analysis, quality_analysis)
            final_confidence = base_confidence * correlation_analysis['correlation_score']
            
            signal['binance_pair'] = binance_pair
            signal['confidence'] = final_confidence
            signal['tech_analysis'] = tech_analysis
            signal['quality_analysis'] = quality_analysis
            signal['correlation_analysis'] = correlation_analysis
            
            analyzed_signals.append(signal)
            
            if correlation_analysis['recommendation'] in ['AVOID', 'CAUTION']:
                print(f"⚠️ КОРРЕЛЯЦИЯ: {binance_pair} - {correlation_analysis['recommendation']} "
                      f"(макс: {correlation_analysis['max_correlation']:.2f})")
            
        return analyzed_signals

    async def _open_best_fresh_signals(self, signals: List[Dict], available_margin: float):
        scalping_count = sum(1 for pos in self.open_positions.values() if pos.get('strategy') == 'scalping')
        main_count = sum(1 for pos in self.open_positions.values() if pos.get('strategy') == 'main')
        
        max_scalping = self.SCALPING_CONFIG.get('max_positions', 3)
        max_main = self.MAIN_CONFIG.get('max_positions', 4)
        
        opened_count = 0
        
        for signal in signals:
            if opened_count >= 2:
                break
                
            binance_pair = signal['binance_pair']
            confidence = signal['confidence']
            quality_score = signal['quality_analysis']['quality_score']
            
            # 🔥 ПРОВЕРЯЕМ КОРРЕЛЯЦИЮ ПЕРЕД ОТКРЫТИЕМ
            correlation_recommendation = signal.get('correlation_analysis', {}).get('recommendation', 'SAFE')
            if correlation_recommendation == 'AVOID':
                print(f"🚫 ПРОПУСК {binance_pair} из-за высокой корреляции")
                continue
                
            if binance_pair in self.open_positions:
                continue
            
            current_available_margin = await self.calculate_available_margin()
            if current_available_margin < self.SCALPING_CONFIG['min_position_size']:
                print("❌ Недостаточно маржи для новых позиций")
                break
            
            if (binance_pair in self.SCALPING_CONFIG['pairs'] and 
                scalping_count < max_scalping and quality_score > 0.75):
                
                if await self._execute_scalping_signal(signal, binance_pair, current_available_margin):
                    scalping_count += 1
                    opened_count += 1
                    print(f"⚡ Скальпинг: {binance_pair}")
                    
            elif (main_count < max_main and quality_score > 0.7 and
                  signal['quality_analysis']['recommended_action'] in ['STRONG_BUY', 'STRONG_SELL']):
                
                if await self._execute_main_signal(signal, binance_pair, confidence, current_available_margin):
                    main_count += 1
                    opened_count += 1
                    print(f"🎯 Основная: {binance_pair}")
        
        print(f"✅ Открыто позиций: {opened_count}")

    async def _execute_scalping_signal(self, signal: Dict, binance_pair: str, available_margin: float) -> bool:
        try:
            config = self.SCALPING_CONFIG
            
            tech_analysis = signal.get('tech_analysis', {})
            confidence = signal.get('confidence', 0.5)
            volatility = tech_analysis.get('volatility', 'low')
            
            position_size_usdt = self.risk_manager.calculate_position_size(
                available_margin, self.risk_per_trade, confidence, volatility, config['leverage']
            )
            
            position_size_usdt = max(
                config['min_position_size'],
                min(position_size_usdt, config['max_position_size'])
            )
            
            atr_percent = tech_analysis.get('indicators', {}).get('atr_percent', 2.0)
            
            # 🔥 ПЕРЕДАЕМ ТИП ОРДЕРА ДЛЯ ПРАВИЛЬНОГО TP/SL
            order_type = signal.get('order_type', '')
            tp, sl = self.risk_manager.calculate_adaptive_tp_sl(atr_percent, 'scalping', order_type)
            
            ticker = self.client.fetch_ticker(binance_pair)
            current_price = ticker.get('last')
            
            if not current_price or current_price <= 0:
                return False
            
            quantity = position_size_usdt / current_price
            
            markets = self.client.load_markets()
            market = markets[binance_pair]
            
            min_amount = market['limits']['amount']['min']
            min_cost = market['limits']['cost']['min'] if market['limits']['cost']['min'] else 20
            
            quantity = max(quantity, min_amount)
            cost = quantity * current_price
            
            if cost < min_cost:
                quantity = min_cost / current_price
            
            quantity = self.client.amount_to_precision(binance_pair, quantity)
            
            order_cost = float(quantity) * current_price
            if order_cost < config['min_position_size']:
                print(f"⚠️ Маленький ордер: ${order_cost:.2f}")
                return False
            
            required_margin = order_cost / config['leverage']
            if required_margin > available_margin:
                print(f"❌ Недостаточно маржи: требуется ${required_margin:.2f}, доступно ${available_margin:.2f}")
                return False
            
            side_emoji = "🟢" if signal['action'] == 'BUY' else "🔴"
            quality_score = signal.get('quality_analysis', {}).get('quality_score', 0)
            
            # 🔥 ДЕТАЛЬНАЯ ИНФОРМАЦИЯ О ПОЗИЦИИ
            print(f"⚡{side_emoji} SCALPING: {binance_pair}")
            print(f"   {signal['action']} | Плечо: {config['leverage']}x")
            print(f"   💰 Размер позиции: ${order_cost:.2f}")
            print(f"   📊 Количество: {float(quantity):.6f}")
            print(f"   💵 Цена входа: {current_price:.6f}")
            print(f"   🎯 TP: {tp:.1f}% | Цель: {current_price * (1 + tp/100) if signal['action'] == 'BUY' else current_price * (1 - tp/100):.6f}")
            print(f"   🛑 SL: {sl:.1f}% | Стоп: {current_price * (1 - sl/100) if signal['action'] == 'BUY' else current_price * (1 + sl/100):.6f}")
            print(f"   📈 Качество: {quality_score:.2f}")
            print(f"   🏦 Маржа: ${required_margin:.2f}")
            
            order_side = 'buy' if signal['action'] == 'BUY' else 'sell'
            
            try:
                self.client.set_leverage(config['leverage'], binance_pair)
            except:
                pass
            
            order = self.client.create_order(
                symbol=binance_pair,
                type='market',
                side=order_side,
                amount=float(quantity)
            )
            
            print(f"✅ ОТКРЫТО: {order['id']}")
            
            self.open_positions[binance_pair] = {
                'size': float(quantity),
                'side': order_side,
                'entry_price': current_price,
                'leverage': config['leverage'],
                'strategy': 'scalping',
                'tp': tp,
                'sl': sl,
                'timestamp': datetime.now().isoformat(),
                'source': signal.get('source', 'scalping_analysis'),
                'direction_emoji': side_emoji,
                'confidence': signal.get('confidence', 0.8),
                'quality_score': quality_score,
                'atr_percent': atr_percent,
                'order_id': order['id'],
                'position_value': order_cost,
                'order_type': order_type,
                'tp_price': current_price * (1 + tp/100) if signal['action'] == 'BUY' else current_price * (1 - tp/100),
                'sl_price': current_price * (1 - sl/100) if signal['action'] == 'BUY' else current_price * (1 + sl/100)
            }
            
            await self.save_state()
            return True
            
        except Exception as e:
            print(f"❌ Ошибка скальпинга: {e}")
            return False

    async def _execute_main_signal(self, signal: Dict, binance_pair: str, confidence: float, available_margin: float) -> bool:
        try:
            config = self.MAIN_CONFIG
            
            tech_analysis = signal.get('tech_analysis', {})
            quality_score = signal.get('quality_analysis', {}).get('quality_score', 0.5)
            volatility = tech_analysis.get('volatility', 'low')
            
            position_size_usdt = self.risk_manager.calculate_position_size(
                available_margin, self.risk_per_trade, confidence, volatility, config['leverage']
            )
            
            position_size_usdt = max(
                config['min_position_size'],
                min(position_size_usdt, config['max_position_size'])
            )
            
            atr_percent = tech_analysis.get('indicators', {}).get('atr_percent', 2.0)
            
            # 🔥 ПЕРЕДАЕМ ТИП ОРДЕРА ДЛЯ ПРАВИЛЬНОГО TP/SL
            order_type = signal.get('order_type', '')
            tp, sl = self.risk_manager.calculate_adaptive_tp_sl(atr_percent, 'main', order_type)
            
            ticker = self.client.fetch_ticker(binance_pair)
            current_price = ticker.get('last')
            
            if not current_price or current_price <= 0:
                return False
            
            quantity = position_size_usdt / current_price
            
            markets = self.client.load_markets()
            market = markets[binance_pair]
            
            min_amount = market['limits']['amount']['min']
            min_cost = market['limits']['cost']['min'] if market['limits']['cost']['min'] else 20
            
            quantity = max(quantity, min_amount)
            cost = quantity * current_price
            
            if cost < min_cost:
                quantity = min_cost / current_price
            
            quantity = self.client.amount_to_precision(binance_pair, quantity)
            
            order_cost = float(quantity) * current_price
            if order_cost < config['min_position_size']:
                print(f"⚠️ Маленький ордер: ${order_cost:.2f}")
                return False
            
            required_margin = order_cost / config['leverage']
            if required_margin > available_margin:
                print(f"❌ Недостаточно маржи: требуется ${required_margin:.2f}, доступно ${available_margin:.2f}")
                return False
            
            side_emoji = "🟢" if signal['action'] == 'BUY' else "🔴"
            
            # 🔥 ДЕТАЛЬНАЯ ИНФОРМАЦИЯ О ПОЗИЦИИ
            print(f"🎯{side_emoji} MAIN: {binance_pair}")
            print(f"   {side_emoji} {signal['action']} | Плечо: {config['leverage']}x")
            print(f"   💰 Размер позиции: ${order_cost:.2f}")
            print(f"   📊 Количество: {float(quantity):.6f}")
            print(f"   💵 Цена входа: {current_price:.6f}")
            print(f"   🎯 TP: {tp:.1f}% | Цель: {current_price * (1 + tp/100) if signal['action'] == 'BUY' else current_price * (1 - tp/100):.6f}")
            print(f"   🛑 SL: {sl:.1f}% | Стоп: {current_price * (1 - sl/100) if signal['action'] == 'BUY' else current_price * (1 + sl/100):.6f}")
            print(f"   📈 Качество: {quality_score:.2f}")
            print(f"   🏦 Маржа: ${required_margin:.2f}")
            
            order_side = 'buy' if signal['action'] == 'BUY' else 'sell'
            
            try:
                self.client.set_leverage(config['leverage'], binance_pair)
            except:
                pass
            
            order = self.client.create_order(
                symbol=binance_pair,
                type='market',
                side=order_side,
                amount=float(quantity)
            )
            
            print(f"✅ ОТКРЫТО: {order['id']}")
            
            self.open_positions[binance_pair] = {
                'size': float(quantity),
                'side': order_side,
                'entry_price': current_price,
                'leverage': config['leverage'],
                'strategy': 'main',
                'tp': tp,
                'sl': sl,
                'timestamp': datetime.now().isoformat(),
                'source': 'minerva_main',
                'confidence': confidence,
                'quality_score': quality_score,
                'direction_emoji': side_emoji,
                'atr_percent': atr_percent,
                'order_id': order['id'],
                'position_value': order_cost,
                'order_type': order_type,
                'tp_price': current_price * (1 + tp/100) if signal['action'] == 'BUY' else current_price * (1 - tp/100),
                'sl_price': current_price * (1 - sl/100) if signal['action'] == 'BUY' else current_price * (1 + sl/100)
            }
            
            await self.save_state()
            return True
            
        except Exception as e:
            print(f"❌ Ошибка основной: {e}")
            return False

    def _calculate_signal_confidence(self, signal: Dict, tech_analysis: Dict, quality_analysis: Dict) -> float:
        confidence = 0.5
        confidence += (tech_analysis.get('score', 0.5) - 0.5) * 0.4
        confidence += (quality_analysis.get('quality_score', 0.5) - 0.5) * 0.4
        if signal.get('is_fresh_signal'):
            confidence += 0.15
        return min(max(confidence, 0.1), 0.95)

    async def _check_scalping_opportunities(self):
        available_margin = await self.calculate_available_margin()
        if available_margin < self.SCALPING_CONFIG['min_position_size']:
            print("❌ Недостаточно маржи для скальпинга")
            return
        
        scalping_count = sum(1 for pos in self.open_positions.values() if pos.get('strategy') == 'scalping')
        
        if scalping_count >= self.SCALPING_CONFIG['max_positions']:
            return
        
        print(f"🔍 Проверяем {len(self.SCALPING_CONFIG['pairs'])} пар...")
        
        opened_scalping = 0
        
        for pair in self.SCALPING_CONFIG['pairs']:
            if scalping_count + opened_scalping >= self.SCALPING_CONFIG['max_positions']:
                break
                
            if pair in self.open_positions:
                continue
            
            current_margin = await self.calculate_available_margin()
            if current_margin < self.SCALPING_CONFIG['min_position_size']:
                break
            
            signal = await self._analyze_for_scalping(pair)
            if signal and signal.get('quality_analysis', {}).get('quality_score', 0) > 0.75:
                if await self._execute_scalping_signal(signal, pair, current_margin):
                    opened_scalping += 1
                    print(f"⚡ Скальпинг: {pair}")
        
        if opened_scalping > 0:
            print(f"✅ Открыто скальпинг: {opened_scalping}")

    async def _analyze_for_scalping(self, pair: str) -> Optional[Dict]:
        try:
            markets = self.client.load_markets()
            if pair not in markets or not markets[pair].get('active', True):
                return None
                
            analysis_5m = await self.technical_analyzer.analyze_trend(pair, self.client, '5m')
            analysis_15m = await self.technical_analyzer.analyze_trend(pair, self.client, '15m')
            
            if 'error' in analysis_5m or 'error' in analysis_15m:
                return None
            
            trend_aligned = (
                analysis_5m['trend'] in ['strong_bullish', 'bullish'] and
                analysis_15m['trend'] in ['strong_bullish', 'bullish', 'neutral']
            ) or (
                analysis_5m['trend'] in ['strong_bearish', 'bearish'] and
                analysis_15m['trend'] in ['strong_bearish', 'bearish', 'neutral']
            )
            
            rsi = analysis_5m.get('indicators', {}).get('rsi', 50)
            momentum_conditions = (
                (analysis_5m['momentum'] in ['bullish', 'oversold'] and rsi < 65 and rsi > 25) or
                (analysis_5m['momentum'] in ['bearish', 'overbought'] and rsi > 35 and rsi < 75)
            )
            
            volatility_ok = analysis_5m['volatility'] in ['medium', 'high']
            volume_boost = analysis_5m.get('indicators', {}).get('volume_ratio', 1) > 1.3
            
            macd_aligned = (
                (analysis_5m.get('indicators', {}).get('macd', 0) > 
                 analysis_5m.get('indicators', {}).get('macd_signal', 0) and
                 analysis_5m['trend'] in ['strong_bullish', 'bullish']) or
                (analysis_5m.get('indicators', {}).get('macd', 0) < 
                 analysis_5m.get('indicators', {}).get('macd_signal', 0) and
                 analysis_5m['trend'] in ['strong_bearish', 'bearish'])
            )
            
            score_ok = (analysis_5m['trend'] in ['strong_bullish', 'bullish'] and analysis_5m['score'] > 0.7) or \
                      (analysis_5m['trend'] in ['strong_bearish', 'bearish'] and analysis_5m['score'] < 0.3)
            
            if trend_aligned and momentum_conditions and volatility_ok and macd_aligned and score_ok:
                action = 'BUY' if analysis_5m['trend'] in ['strong_bullish', 'bullish'] else 'SELL'
                direction_emoji = '🟢' if action == 'BUY' else '🔴'
                
                fake_signal = {
                    'ticker': pair.replace('/USDT:USDT', ''),
                    'signal_type': '6P' if action == 'BUY' else '6N',
                    'action': action
                }
                quality_analysis = self.signal_analyzer.evaluate_signal_quality(fake_signal, analysis_5m)
                
                return {
                    'ticker': pair.replace('/USDT:USDT', '').replace('USDT:USDT', ''),
                    'action': action,
                    'signal_type': 'SCALP',
                    'direction_emoji': direction_emoji,
                    'source': 'scalping_analysis',
                    'confidence': analysis_5m['score'],
                    'quality_analysis': quality_analysis,
                    'tech_analysis': analysis_5m
                }
            
            return None
            
        except:
            return None

    async def manage_existing_positions(self):
        if not self.open_positions:
            return
            
        print(f'🔍 Управляем {len(self.open_positions)} позициями...')
        
        total_pnl_usdt = 0
        total_invested_usdt = 0
        scalping_pnl = 0
        main_pnl = 0
        
        for symbol, position in list(self.open_positions.items()):
            try:
                ticker = self.client.fetch_ticker(symbol)
                current_price = ticker['last']
                entry_price = position['entry_price']
                position_size = position['size']
                leverage = position.get('leverage', 1)
                strategy = position.get('strategy', 'main')
                
                if position['side'] == 'buy':
                    pnl_pct = (current_price - entry_price) / entry_price * 100
                    pnl_usdt = (current_price - entry_price) * position_size
                else:
                    pnl_pct = (entry_price - current_price) / entry_price * 100
                    pnl_usdt = (entry_price - current_price) * position_size
                
                total_pnl_usdt += pnl_usdt
                position_value = position_size * entry_price
                total_invested_usdt += position_value
                
                if strategy == 'scalping':
                    scalping_pnl += pnl_usdt
                else:
                    main_pnl += pnl_usdt
                
                # 🔥 ОБНОВЛЯЕМ ТРЕЙЛИНГ-СТОП
                trailing_stop_price, should_close_trailing = self.risk_manager.update_trailing_stop(
                    symbol, current_price, position
                )
                
                if should_close_trailing:
                    print(f'🎯 ТРЕЙЛИНГ СТОП: {symbol} - закрытие по трейлингу')
                    await self.close_real_position(symbol, position)
                    continue
                
                # 🔥 ПРОВЕРЯЕМ МАСШТАБИРОВАНИЕ ПОЗИЦИИ
                available_margin = await self.calculate_available_margin()
                scaling_recommendation = self.risk_manager.check_position_scaling(
                    symbol, current_price, position, available_margin
                )
                
                if scaling_recommendation['should_scale']:
                    print(f"📈 МАСШТАБИРОВАНИЕ: {symbol} - добавляем ${scaling_recommendation['scale_size']:.2f}")
                    await self._scale_position(symbol, position, scaling_recommendation['scale_size'])
                
                strategy_emoji = "⚡" if strategy == 'scalping' else "🎯"
                direction_emoji = position.get('direction_emoji', '⚪')
                pnl_usdt_str = f"+${pnl_usdt:.2f}" if pnl_usdt > 0 else f"-${abs(pnl_usdt):.2f}"
                
                print(f'{strategy_emoji}{direction_emoji} {symbol}: {position["side"].upper()} | '
                      f'PnL: {pnl_pct:+.1f}% ({pnl_usdt_str})')
                
                tp = position.get('tp', 4.0)
                sl = position.get('sl', 2.0)
                
                if pnl_pct >= tp:
                    print(f'🎯 Фиксируем прибыль {symbol}: +{pnl_pct:.1f}%')
                    await self.close_real_position(symbol, position)
                elif pnl_pct <= -sl:
                    print(f'🛑 Стоп-лосс {symbol}: {pnl_pct:.1f}%')
                    await self.close_real_position(symbol, position)
                    
            except Exception as e:
                print(f'❌ Ошибка позиции {symbol}: {e}')
        
        current_balance = self.trading_state.get('balance', self.capital)
        new_balance = current_balance + total_pnl_usdt
        
        if total_invested_usdt > 0:
            total_pnl_pct = (total_pnl_usdt / total_invested_usdt) * 100
            total_pnl_str = f"+${total_pnl_usdt:.2f}" if total_pnl_usdt > 0 else f"-${abs(total_pnl_usdt):.2f}"
            
            print(f'💰 PnL: {total_pnl_pct:+.1f}% ({total_pnl_str})')
            print(f'   ⚡ Скальпинг: ${scalping_pnl:+.2f} | 🎯 Основная: ${main_pnl:+.2f}')
            print(f'   💵 Баланс: ${new_balance:.2f}')
            
            self.trading_state['scalping_pnl'] = scalping_pnl
            self.trading_state['main_pnl'] = main_pnl
            self.trading_state['total_pnl'] = total_pnl_usdt
            self.trading_state['balance'] = new_balance

    async def _scale_position(self, symbol: str, position: Dict, scale_size: float):
        """Масштабирование позиции - добавление к winning trade"""
        try:
            ticker = self.client.fetch_ticker(symbol)
            current_price = ticker.get('last')
            
            if not current_price or current_price <= 0:
                return False
            
            # Рассчитываем количество для добавления
            quantity_to_add = scale_size / current_price
            
            markets = self.client.load_markets()
            market = markets[symbol]
            
            min_amount = market['limits']['amount']['min']
            quantity_to_add = max(quantity_to_add, min_amount)
            quantity_to_add = self.client.amount_to_precision(symbol, quantity_to_add)
            
            # Исполняем ордер на добавление
            order_side = position['side']  # Тот же direction
            
            order = self.client.create_order(
                symbol=symbol,
                type='market',
                side=order_side,
                amount=float(quantity_to_add)
            )
            
            # Обновляем позицию
            new_size = position['size'] + float(quantity_to_add)
            new_position_value = position.get('position_value', 0) + scale_size
            
            position['size'] = new_size
            position['position_value'] = new_position_value
            position['scaled_count'] = position.get('scaled_count', 0) + 1
            position['last_scale_time'] = datetime.now().isoformat()
            
            print(f"✅ МАСШТАБИРОВАНО: {symbol} +${scale_size:.2f} | Новый размер: ${new_position_value:.2f}")
            
            await self.save_state()
            return True
            
        except Exception as e:
            print(f"❌ Ошибка масштабирования {symbol}: {e}")
            return False

    async def close_real_position(self, symbol: str, position: Dict):
        try:
            ticker = self.client.fetch_ticker(symbol)
            current_price = ticker['last']
            entry_price = position['entry_price']
            position_size = position['size']
            position_value = position.get('position_value', 0)
            
            if position['side'] == 'buy':
                pnl_usdt = (current_price - entry_price) * position_size
                pnl_percent = (current_price - entry_price) / entry_price * 100
                close_side = 'sell'
            else:
                pnl_usdt = (entry_price - current_price) * position_size
                pnl_percent = (entry_price - current_price) / entry_price * 100
                close_side = 'buy'
            
            strategy_emoji = "⚡" if position.get('strategy') == 'scalping' else "🎯"
            direction_emoji = position.get('direction_emoji', '⚪')
            pnl_str = f"+${pnl_usdt:.2f}" if pnl_usdt > 0 else f"-${abs(pnl_usdt):.2f}"
            
            print(f'{strategy_emoji}{direction_emoji} ЗАКРЫТИЕ {symbol}: PnL {pnl_str} ({pnl_percent:+.1f}%)')
            
            close_order = self.client.create_order(
                symbol=symbol,
                type='market',
                side=close_side,
                amount=position_size
            )
            
            print(f"✅ ЗАКРЫТО: {close_order['id']}")
            
            # 🔥 ОБНОВЛЯЕМ СТАТИСТИКУ ЗАКРЫТЫХ ПОЗИЦИЙ
            self._update_closed_positions_stats(pnl_usdt, pnl_percent)
            
            # 🔥 ОЧИЩАЕМ ДАННЫЕ ТРЕЙЛИНГ-СТОПА
            self.risk_manager.cleanup_trailing_data(symbol)
            
            self.trading_state['balance'] += pnl_usdt
            del self.open_positions[symbol]
            await self.save_state()
            
        except Exception as e:
            print(f'❌ Ошибка закрытия {symbol}: {e}')

    def _update_closed_positions_stats(self, pnl_usdt: float, pnl_percent: float):
        """Обновляем статистику закрытых позиций"""
        self.closed_positions_stats['total_closed'] += 1
        
        if pnl_usdt > 0:
            self.closed_positions_stats['profitable_trades'] += 1
            self.closed_positions_stats['total_profit'] += pnl_usdt
            self.closed_positions_stats['current_streak'] = max(0, self.closed_positions_stats['current_streak']) + 1
            self.closed_positions_stats['best_streak'] = max(self.closed_positions_stats['best_streak'], self.closed_positions_stats['current_streak'])
            
            if pnl_usdt > self.closed_positions_stats['largest_win']:
                self.closed_positions_stats['largest_win'] = pnl_usdt
        else:
            self.closed_positions_stats['unprofitable_trades'] += 1
            self.closed_positions_stats['total_loss'] += abs(pnl_usdt)
            self.closed_positions_stats['current_streak'] = min(0, self.closed_positions_stats['current_streak']) - 1
            self.closed_positions_stats['worst_streak'] = min(self.closed_positions_stats['worst_streak'], self.closed_positions_stats['current_streak'])
            
            if abs(pnl_usdt) > self.closed_positions_stats['largest_loss']:
                self.closed_positions_stats['largest_loss'] = abs(pnl_usdt)

    def print_closed_positions_stats(self):
        """Печатаем статистику закрытых позиций"""
        stats = self.closed_positions_stats
        
        if stats['total_closed'] == 0:
            return
        
        print(f"\n📊 СТАТИСТИКА ЗАКРЫТЫХ ПОЗИЦИЙ:")
        print("=" * 50)
        print(f"📈 В ПЛЮС: {stats['profitable_trades']} сделок")
        print(f"   💰 Общий профит: +${stats['total_profit']:.2f}")
        print(f"   🏆 Лучшая сделка: +${stats['largest_win']:.2f}")
        print(f"")
        print(f"📉 В МИНУС: {stats['unprofitable_trades']} сделок")  
        print(f"   💸 Общий убыток: -${stats['total_loss']:.2f}")
        print(f"   🔻 Худшая сделка: -${stats['largest_loss']:.2f}")
        print(f"")
        print(f"📋 ВСЕГО: {stats['total_closed']} сделок")
        
        if stats['total_closed'] > 0:
            win_rate = (stats['profitable_trades'] / stats['total_closed']) * 100
            total_net = stats['total_profit'] - stats['total_loss']
            avg_win = stats['total_profit'] / stats['profitable_trades'] if stats['profitable_trades'] > 0 else 0
            avg_loss = stats['total_loss'] / stats['unprofitable_trades'] if stats['unprofitable_trades'] > 0 else 0
            
            print(f"   🎯 Win Rate: {win_rate:.1f}%")
            print(f"   💵 Чистый PnL: ${total_net:+.2f}")
            print(f"   📊 Средний выигрыш: ${avg_win:.2f}")
            print(f"   📉 Средний проигрыш: ${avg_loss:.2f}")
            print(f"   🔥 Лучшая серия: {stats['best_streak']} побед")
            print(f"   ❌ Худшая серия: {abs(stats['worst_streak'])} поражений")
        
        print("=" * 50)

    async def convert_ticker_to_binance_format(self, ticker: str) -> str:
        try:
            ticker_clean = ticker.upper().strip()
            markets = self.client.load_markets()
            
            possible_pairs = [
                f"{ticker_clean}/USDT:USDT",
                f"{ticker_clean}USDT:USDT",
                f"{ticker_clean}-USDT:USDT"
            ]
            
            for pair in possible_pairs:
                if pair in markets and markets[pair].get('active', True):
                    return pair
            
            return None
            
        except:
            return None

    async def update_dynamic_pairs(self):
        try:
            minerva_signals = await self.minerva.get_fresh_signals()
            
            new_dynamic_pairs = []
            self.all_scanner_signals.clear()
            
            for signal in minerva_signals:
                binance_pair = await self.convert_ticker_to_binance_format(signal['ticker'])
                if binance_pair:
                    new_dynamic_pairs.append(binance_pair)
                    self.all_scanner_signals[binance_pair] = signal
            
            self.dynamic_pairs = list(set(new_dynamic_pairs))
            
            print(f"🔄 Динамические пары: {len(self.dynamic_pairs)}")
            
        except Exception as e:
            print(f"❌ Ошибка обновления пар: {e}")

    async def calculate_available_margin(self) -> float:
        total_balance = self.trading_state.get('balance', self.capital)
        used_margin = self.trading_state.get('used_margin', 0)
        
        total_used = 0
        for symbol, position in self.open_positions.items():
            position_size = position.get('size', 0)
            entry_price = position.get('entry_price', 0)
            leverage = position.get('leverage', 1)
            
            if position_size > 0 and entry_price > 0:
                position_value = position_size * entry_price
                position_margin = position_value / leverage
                total_used += position_margin
        
        available = total_balance - total_used
        self.trading_state['used_margin'] = total_used
        self.trading_state['free_margin'] = available
        
        return max(0, available)

    async def print_balance_report(self):
        print("\n📊 ОТЧЕТ О БАЛАНСЕ И СТРАТЕГИИ:")
        print("=" * 50)
        print(f"💰 Общий баланс: ${self.trading_state['balance']:.2f}")
        print(f"🎯 Уровень риска: {self.trading_state['balance_tier'].upper()}")
        print(f"📈 Свободная маржа: ${self.trading_state['free_margin']:.2f}")
        print(f"🛡️ Использовано маржи: ${self.trading_state['used_margin']:.2f}")
        print(f"🎯 Активных позиций: {len(self.open_positions)}/{self.max_total_positions}")
        
        settings = self.trading_state.get('strategy_settings', {})
        if settings:
            print(f"⚡ Множитель риска: {settings.get('risk_multiplier', 1.0)}x")
        
        print("=" * 50)

    async def trading_cycle(self):
        print('🎯 Запуск торговли...')
        
        iteration = 0
        while self.is_running:
            try:
                iteration += 1
                print(f'\n📊 Итерация {iteration}')
                print('=' * 50)
                
                if iteration % 10 == 1:
                    await self.print_balance_report()
                
                available_margin = await self.calculate_available_margin()
                
                await self._check_scalping_opportunities()
                
                if self.all_scanner_signals:
                    await self.process_fresh_signals(list(self.all_scanner_signals.values()))
                
                await self.manage_existing_positions()
                
                if iteration % 3 == 0:
                    print("🔄 Обновляем пары...")
                    await self.update_dynamic_pairs()
                
                # 🔥 ВЫВОДИМ СТАТИСТИКУ КАЖДЫЕ 5 ИТЕРАЦИЙ
                if iteration % 5 == 0 and self.closed_positions_stats['total_closed'] > 0:
                    self.print_closed_positions_stats()
                
                await self.save_state()
                print('=' * 50)
                await asyncio.sleep(30)
                
            except Exception as e:
                print(f'❌ Ошибка цикла: {e}')
                await asyncio.sleep(10)

    async def _close_all_real_positions(self):
        print("🗑️ Закрываем все позиции...")
        closed_count = 0
        
        for symbol, position in list(self.open_positions.items()):
            try:
                await self.close_real_position(symbol, position)
                closed_count += 1
            except Exception as e:
                print(f"   ❌ Ошибка {symbol}: {e}")
        
        await self.save_state()
        print(f"✅ Закрыто: {closed_count}")

    async def recover_state(self):
        self.open_positions, self.trading_state = await load_state()
        
        if self.trading_state.get('balance', 0) <= 0:
            print("⚠️  Баланс в состоянии 0, обновляем из Binance...")
            try:
                total_balance = await self.client.get_total_balance()
                self.trading_state['balance'] = total_balance
                self.trading_state['free_margin'] = total_balance
                print(f"💰 Обновленный баланс: ${total_balance:.2f}")
            except Exception as e:
                print(f"❌ Ошибка получения баланса: {e}")
        
        await self.save_state()

    async def save_state(self):
        await save_state(self.open_positions, self.trading_state)

    async def safe_shutdown(self):
        print('🛑 Завершение...')
        print(f'💾 Активных позиций: {len(self.open_positions)}')
        final_balance = self.trading_state.get('balance', self.capital)
        print(f'💰 Баланс: ${final_balance:.2f}')
        
        # 🔥 ФИНАЛЬНАЯ СТАТИСТИКА ПРИ ЗАВЕРШЕНИИ
        if self.closed_positions_stats['total_closed'] > 0:
            self.print_closed_positions_stats()
        
        self.is_running = False
        await self.minerva.close_session()
        await self.save_state()

    async def start_trading(self):
        self.is_running = True
        
        try:
            await asyncio.gather(
                self.trading_cycle(),
                self.minerva.start_monitoring(interval=MINERVA_CHECK_INTERVAL)
            )
        except KeyboardInterrupt:
            print('\n⏹️ Остановка')
            await self.safe_shutdown()
        except Exception as e:
            print(f'\n❌ Ошибка: {e}')
            await self.safe_shutdown()