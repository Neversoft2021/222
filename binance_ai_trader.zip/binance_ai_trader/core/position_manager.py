﻿from typing import Dict, List
from datetime import datetime


class PositionManager:
    def __init__(self, binance_client):
        self.client = binance_client
        self.closed_positions_stats = {
            'total_closed': 0,
            'profitable_trades': 0,
            'unprofitable_trades': 0,
            'total_profit': 0.0,
            'total_loss': 0.0,
            'largest_win': 0.0,
            'largest_loss': 0.0,
            'current_streak': 0,
            'best_streak': 0,
            'worst_streak': 0,
            'avg_win': 0.0,
            'avg_loss': 0.0,
            'win_rate': 0.0,
            'profit_factor': 0.0,
            'expectancy': 0.0
        }

    async def interactive_position_management(self, open_positions: Dict):
        """Интерактивное управление позициями при запуске"""
        if not open_positions:
            print("📭 Нет открытых позиций для управления")
            return

        print(f'\n🎯 УПРАВЛЕНИЕ ОТКРЫТЫМИ ПОЗИЦИЯМИ')
        print('=' * 60)
        
        # Получаем актуальные цены для всех позиций
        positions_with_pnl = []
        for symbol, position in open_positions.items():
            try:
                ticker = await self.client.fetch_ticker(symbol)
                current_price = ticker['last']
                entry_price = position['entry_price']
                position_size = position['size']
                
                if position['side'] == 'long':
                    pnl_usdt = (current_price - entry_price) * position_size
                    pnl_percent = (current_price - entry_price) / entry_price * 100
                else:
                    pnl_usdt = (entry_price - current_price) * position_size
                    pnl_percent = (entry_price - current_price) / entry_price * 100
                
                positions_with_pnl.append({
                    'symbol': symbol,
                    'position': position,
                    'current_price': current_price,
                    'pnl_usdt': pnl_usdt,
                    'pnl_percent': pnl_percent
                })
                
            except Exception as e:
                print(f'❌ Ошибка получения цены для {symbol}: {e}')
        
        # Сортируем по убыванию PnL
        positions_with_pnl.sort(key=lambda x: x['pnl_usdt'], reverse=True)
        
        # Выводим список позиций
        print(f"📊 ОТКРЫТЫЕ ПОЗИЦИИ ({len(positions_with_pnl)}):")
        print('-' * 60)
        
        for i, pos_data in enumerate(positions_with_pnl, 1):
            symbol = pos_data['symbol']
            position = pos_data['position']
            pnl_usdt = pos_data['pnl_usdt']
            pnl_percent = pos_data['pnl_percent']
            current_price = pos_data['current_price']
            
            strategy_emoji = "⚡" if position.get('strategy') == 'scalping' else "🎯"
            direction_emoji = "🟢" if position['side'] == 'long' else "🔴"
            pnl_str = f"+${pnl_usdt:.2f}" if pnl_usdt > 0 else f"-${abs(pnl_usdt):.2f}"
            
            print(f"{i:2d}. {strategy_emoji}{direction_emoji} {symbol}")
            print(f"    📊 {position['side'].upper()} | Размер: {position['size']:.6f}")
            print(f"    💵 Вход: {position['entry_price']:.6f} | Текущая: {current_price:.6f}")
            print(f"    📈 PnL: {pnl_percent:+.2f}% ({pnl_str})")
            print(f"    ⚡ Плечо: {position.get('leverage', 1)}x")
            print(f"    ⏰ Открыта: {position['timestamp'][11:16]}")
            print()
        
        # Запрос действий от пользователя
        print('🎯 ВЫБЕРИТЕ ДЕЙСТВИЕ:')
        print('   1. Закрыть ВСЕ позиции')
        print('   2. Закрыть только убыточные позиции')
        print('   3. Закрыть конкретные позиции (по номерам)')
        print('   4. ПРОДОЛЖИТЬ без изменений')
        print('   5. ОТМЕНА запуска')
        
        choice = input('\n🎯 Ваш выбор (1-5): ').strip()
        
        if choice == '1':
            print("🗑️ Закрываем ВСЕ позиции...")
            await self.close_all_positions(open_positions)
            print("✅ Все позиции закрыты")
            
        elif choice == '2':
            print("📉 Закрываем только убыточные позиции...")
            closed_count = 0
            for pos_data in positions_with_pnl:
                if pos_data['pnl_usdt'] < 0:
                    await self.close_position(pos_data['symbol'], pos_data['position'])
                    closed_count += 1
                    del open_positions[pos_data['symbol']]
            print(f"✅ Закрыто убыточных позиций: {closed_count}")
            
        elif choice == '3':
            print("🔢 Закрываем выбранные позиции...")
            numbers_input = input("Введите номера позиций через запятую (например: 1,3,5): ").strip()
            try:
                numbers = [int(num.strip()) for num in numbers_input.split(',')]
                closed_count = 0
                for num in numbers:
                    if 1 <= num <= len(positions_with_pnl):
                        pos_data = positions_with_pnl[num-1]
                        await self.close_position(pos_data['symbol'], pos_data['position'])
                        closed_count += 1
                        del open_positions[pos_data['symbol']]
                    else:
                        print(f"⚠️ Неверный номер: {num}")
                print(f"✅ Закрыто выбранных позиций: {closed_count}")
            except ValueError:
                print("❌ Ошибка ввода. Используйте формат: 1,3,5")
                
        elif choice == '4':
            print("🚀 ПРОДОЛЖАЕМ без изменений позиций")
            return
            
        elif choice == '5':
            print("❌ ОТМЕНА запуска")
            exit()
            
        else:
            print("❌ Неверный выбор. Продолжаем без изменений.")

    async def manage_open_positions(self, open_positions: Dict):
        """Управляет открытыми позициями"""
        try:
            for symbol, position in list(open_positions.items()):
                # Проверяем стоп-лоссы и тейк-профиты
                await self._check_position_limits(symbol, position, open_positions)
                
                # Обновляем информацию о позиции
                await self._update_position_info(symbol, position)
                
        except Exception as e:
            print(f"❌ Ошибка управления позициями: {e}")

    async def _check_position_limits(self, symbol: str, position: Dict, open_positions: Dict):
        """Проверяет стоп-лосс и тейк-профит для позиции"""
        try:
            ticker = await self.client.fetch_ticker(symbol)
            current_price = ticker['last']
            entry_price = position['entry_price']
            
            # Расчет PnL
            if position['side'] == 'long':
                pnl_percent = (current_price - entry_price) / entry_price * 100
            else:
                pnl_percent = (entry_price - current_price) / entry_price * 100
            
            # Проверка стоп-лосса и тейк-профита
            stop_loss = position.get('stop_loss', 2.0)
            take_profit = position.get('take_profit', 4.0)
            
            if pnl_percent <= -stop_loss:
                print(f"🛑 СТОП-ЛОСС {symbol}: PnL {pnl_percent:.2f}%")
                await self.close_position(symbol, position)
                if symbol in open_positions:
                    del open_positions[symbol]
            elif pnl_percent >= take_profit:
                print(f"🎯 ТЕЙК-ПРОФИТ {symbol}: PnL {pnl_percent:.2f}%")
                await self.close_position(symbol, position)
                if symbol in open_positions:
                    del open_positions[symbol]
            elif abs(pnl_percent) > 2.0:
                pnl_str = f"+{pnl_percent:.2f}%" if pnl_percent > 0 else f"{pnl_percent:.2f}%"
                print(f"📊 {symbol}: PnL {pnl_str}")
                
        except Exception as e:
            print(f"❌ Ошибка проверки лимитов {symbol}: {e}")

    async def _update_position_info(self, symbol: str, position: Dict):
        """Обновляет информацию о позиции"""
        try:
            real_positions = await self.client.get_open_positions()
            if symbol in real_positions:
                real_pos = real_positions[symbol]
                position.update({
                    'unrealized_pnl': real_pos.get('unrealized_pnl', 0),
                    'liquidation_price': real_pos.get('liquidation_price', 0)
                })
                
        except Exception as e:
            print(f"❌ Ошибка обновления позиции {symbol}: {e}")

    async def close_position(self, symbol: str, position: Dict):
        """Закрывает позицию на Binance"""
        try:
            ticker = await self.client.fetch_ticker(symbol)
            current_price = ticker['last']
            entry_price = position['entry_price']
            position_size = position['size']
            
            if position['side'] == 'long':
                pnl_usdt = (current_price - entry_price) * position_size
                pnl_percent = (current_price - entry_price) / entry_price * 100
                close_side = 'sell'
            else:
                pnl_usdt = (entry_price - current_price) * position_size
                pnl_percent = (entry_price - current_price) / entry_price * 100
                close_side = 'buy'
            
            strategy_emoji = "⚡" if position.get('strategy') == 'scalping' else "🎯"
            direction_emoji = "🟢" if position['side'] == 'long' else "🔴"
            pnl_str = f"+${pnl_usdt:.2f}" if pnl_usdt > 0 else f"-${abs(pnl_usdt):.2f}"
            
            print(f'{strategy_emoji}{direction_emoji} ЗАКРЫТИЕ {symbol}: PnL {pnl_str} ({pnl_percent:+.1f}%)')
            
            close_order = await self.client.create_order(
                symbol=symbol,
                type='market',
                side=close_side,
                amount=position_size
            )
            
            print(f"✅ ЗАКРЫТО: {close_order['id']}")
            
            self._update_closed_positions_stats(pnl_usdt, pnl_percent)
            
        except Exception as e:
            print(f'❌ Ошибка закрытия {symbol}: {e}')

    async def close_all_positions(self, open_positions: Dict):
        """Закрывает все открытые позиции"""
        print("🗑️ Закрываем все позиции...")
        closed_count = 0
        
        for symbol, position in list(open_positions.items()):
            try:
                await self.close_position(symbol, position)
                closed_count += 1
                del open_positions[symbol]
            except Exception as e:
                print(f"   ❌ Ошибка {symbol}: {e}")
        
        print(f"✅ Закрыто: {closed_count}")

    def _update_closed_positions_stats(self, pnl_usdt: float, pnl_percent: float):
        """Обновляет статистику закрытых позиций"""
        self.closed_positions_stats['total_closed'] += 1
        
        if pnl_usdt > 0:
            self.closed_positions_stats['profitable_trades'] += 1
            self.closed_positions_stats['total_profit'] += pnl_usdt
            self.closed_positions_stats['current_streak'] = max(0, self.closed_positions_stats['current_streak']) + 1
            self.closed_positions_stats['best_streak'] = max(self.closed_positions_stats['best_streak'], self.closed_positions_stats['current_streak'])
            if pnl_usdt > self.closed_positions_stats['largest_win']:
                self.closed_positions_stats['largest_win'] = pnl_usdt
        else:
            self.closed_positions_stats['unprofitable_trades'] += 1
            self.closed_positions_stats['total_loss'] += abs(pnl_usdt)
            self.closed_positions_stats['current_streak'] = min(0, self.closed_positions_stats['current_streak']) - 1
            self.closed_positions_stats['worst_streak'] = min(self.closed_positions_stats['worst_streak'], self.closed_positions_stats['current_streak'])
            if abs(pnl_usdt) > self.closed_positions_stats['largest_loss']:
                self.closed_positions_stats['largest_loss'] = abs(pnl_usdt)
        
        # Обновляем средние значения
        if self.closed_positions_stats['profitable_trades'] > 0:
            self.closed_positions_stats['avg_win'] = self.closed_positions_stats['total_profit'] / self.closed_positions_stats['profitable_trades']
        
        if self.closed_positions_stats['unprofitable_trades'] > 0:
            self.closed_positions_stats['avg_loss'] = self.closed_positions_stats['total_loss'] / self.closed_positions_stats['unprofitable_trades']
        
        # Расчет винрейта
        if self.closed_positions_stats['total_closed'] > 0:
            self.closed_positions_stats['win_rate'] = (self.closed_positions_stats['profitable_trades'] / self.closed_positions_stats['total_closed']) * 100
        
        # Расчет profit factor
        if self.closed_positions_stats['total_loss'] > 0:
            self.closed_positions_stats['profit_factor'] = self.closed_positions_stats['total_profit'] / self.closed_positions_stats['total_loss']
        
        # Расчет expectancy
        win_rate = self.closed_positions_stats['win_rate'] / 100
        avg_win = self.closed_positions_stats['avg_win']
        avg_loss = self.closed_positions_stats['avg_loss']
        self.closed_positions_stats['expectancy'] = (win_rate * avg_win) - ((1 - win_rate) * avg_loss)

    def get_closed_stats(self) -> Dict:
        """Возвращает статистику закрытых позиций"""
        return self.closed_positions_stats.copy()