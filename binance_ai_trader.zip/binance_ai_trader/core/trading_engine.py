﻿import asyncio
import json
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import numpy as np

from integrations.binance_client import BinanceClient
from integrations.minerva_integration import RealMinervaIntegration
from analysis.technical_analyzer import AdvancedTechnicalAnalyzer
from analysis.signal_analyzer import SignalQualityAnalyzer
from analysis.risk_manager import AdaptiveRiskManager
from core.balance_manager import BalanceAnalyzer
from core.margin_manager import MarginManager
from utils.file_manager import save_state, load_state
from config.settings import *
from config.risk_config import *

from core.market_analyzer import MarketAnalyzer
from core.position_manager import PositionManager
from core.performance_tracker import PerformanceTracker


class TradingEngine:
    def __init__(self):
        self.client = BinanceClient(API_KEY, SECRET_KEY)
        self.is_running = False
        self.capital = 0
        self.risk_per_trade = RISK_PER_TRADE
        
        # Инициализация модулей
        self.market_analyzer = MarketAnalyzer(self.client)
        self.position_manager = PositionManager(self.client)
        self.performance_tracker = PerformanceTracker()
        
        self.SCALPING_CONFIG = {}
        self.MAIN_CONFIG = {}
        self.balance_analyzer = BalanceAnalyzer()
        self.margin_manager = MarginManager()
        
        self.dynamic_pairs = []
        self.cooldown_periods = {}
        
        self.minerva = RealMinervaIntegration(self)
        self.technical_analyzer = AdvancedTechnicalAnalyzer()
        self.risk_manager = AdaptiveRiskManager()
        self.signal_analyzer = SignalQualityAnalyzer()
        
        self.open_positions = {}
        self.pending_orders = {}

    async def initialize(self):
        """Полная инициализация торговой системы"""
        print('🚀 Инициализация DeepSeek Binance AI...')
        
        try:
            # Предварительные проверки
            await self._pre_initialization_checks()
            
            # Инициализация Binance
            print("🔧 Настраиваем Binance...")
            if not await self.client.initialize():
                print("❌ Не удалось инициализировать Binance")
                return False
            
            # Анализ баланса и настройка стратегии
            print("💰 Анализируем баланс и настраиваем стратегию...")
            total_balance = await self.client.get_total_balance()
            
            if total_balance <= 0:
                print('❌ Нет средств на счете!')
                return False
            
            # Настройка стратегии на основе баланса
            balance_analysis = self.balance_analyzer.analyze_balance(total_balance)
            await self._setup_strategy_based_on_balance(total_balance, balance_analysis)
            
            # Инициализация состояния
            self.capital = total_balance
            self.performance_tracker.initialize(total_balance)
            
            # Валидация торговых пар
            await self._validate_scalping_pairs()
            
            # Восстановление состояния
            await self.recover_state()
            
            # Анализ рынка
            await self.market_analyzer.analyze_market_conditions(self.dynamic_pairs)
            
            # Настройка плеча и маржи
            await self._setup_leverage_and_margin()
            
            # Вывод итоговой информации
            await self._print_initialization_summary(total_balance, balance_analysis)
            
            # Управление существующими позициями
            active_positions = len(self.open_positions)
            if active_positions > 0:
                await self.position_manager.interactive_position_management(self.open_positions)
            else:
                print("📭 Нет открытых позиций для управления")
            
            # Инициализация Minerva
            if await self.minerva.initialize():
                print("✅ Minerva готова")
            else:
                print("❌ Minerva не инициализирована")
                return False
            
            print(f"🎯 Финальная проверка: Баланс ${total_balance:.2f}")
            return True
            
        except Exception as e:
            print(f'❌ Ошибка инициализации: {e}')
            import traceback
            traceback.print_exc()
            return False

    async def _pre_initialization_checks(self):
        """Предварительные проверки перед инициализацией"""
        print("🔍 Выполняем предварительные проверки...")
        
        # Проверка подключения к интернету
        try:
            import socket
            socket.create_connection(("8.8.8.8", 53), timeout=5)
            print("   ✅ Интернет соединение")
        except:
            print("   ❌ Нет интернет соединения")
            raise
        
        # Проверка времени системы
        current_time = datetime.now()
        print(f"   ✅ Время системы: {current_time}")
        
        # Упрощенная проверка Binance
        try:
            test_client = BinanceClient(API_KEY, SECRET_KEY)
            print("   ✅ Binance клиент создан")
        except Exception as e:
            print(f"   ❌ Ошибка создания Binance клиента: {e}")
            raise Exception(f"Binance клиент не создан: {e}")

    async def _setup_leverage_and_margin(self):
        """Настройка плеча и режима маржи для торговых пар"""
        print("⚡ Настраиваем плечо и маржи...")
        
        try:
            scalping_leverage = self.SCALPING_CONFIG['leverage']
            
            for pair in self.dynamic_pairs:
                try:
                    await self.client.set_leverage(pair, scalping_leverage)
                    await self.client.set_margin_mode(pair, 'isolated')
                    print(f"   ✅ {pair}: плечо {scalping_leverage}x")
                    
                except Exception as e:
                    if "No need to change margin type" not in str(e):
                        print(f"   ⚠️ {pair}: {e}")
                    
        except Exception as e:
            print(f"❌ Ошибка настройки плеча и маржи: {e}")

    async def _setup_strategy_based_on_balance(self, total_balance: float, balance_analysis: Dict):
        """Настраивает стратегию на основе баланса"""
        tier = balance_analysis['tier']
        
        print(f"🎯 АДАПТИВНАЯ НАСТРОЙКА ДЛЯ БАЛАНСА ${total_balance:.2f}")
        print(f"   📊 Уровень: {tier.upper()}")
        print(f"   🎯 Всего позиций: {balance_analysis['max_total_positions']}")
        
        self.SCALPING_CONFIG = {
            'pairs': SCALPING_PAIRS,
            'leverage': balance_analysis['scalping_leverage'],
            'max_positions': balance_analysis['max_scalping_positions'],
            'min_position_size': balance_analysis['scalping_min_position'],
            'max_position_size': balance_analysis['scalping_max_position'],
        }
        
        self.MAIN_CONFIG = {
            'leverage': balance_analysis['main_leverage'],
            'max_positions': balance_analysis['max_main_positions'],
            'min_position_size': balance_analysis['main_min_position'],
            'max_position_size': balance_analysis['main_max_position'],
        }
        
        self.max_total_positions = balance_analysis['max_total_positions']

    async def _validate_scalping_pairs(self):
        """Проверяет доступность пар для скальпинга"""
        print("🔍 Проверяем пары...")
        markets = self.client.load_markets()
        available_pairs = []
        
        for pair in SCALPING_PAIRS:
            if pair in markets:
                print(f"   ✅ {pair}")
                available_pairs.append(pair)
            else:
                print(f"   ❌ {pair} - недоступна")
        
        self.dynamic_pairs = available_pairs
        print(f"📊 Доступно пар: {len(available_pairs)}")

    async def recover_state(self):
        """Восстанавливает состояние"""
        try:
            state = load_state()
            if state:
                self.open_positions = state.get('open_positions', {})
                print(f"📁 Загружено позиций из файла: {len(self.open_positions)}")
            
            await self.sync_with_binance_positions()
            
        except Exception as e:
            print(f"❌ Ошибка восстановления состояния: {e}")
            self.open_positions = {}

    async def sync_with_binance_positions(self):
        """Синхронизирует с реальными позициями на Binance"""
        try:
            print("🔄 Синхронизация с реальными позициями Binance...")
            
            real_positions = await self.client.get_open_positions()
            
            if real_positions:
                print(f"🔍 Найдено реальных позиций на Binance: {len(real_positions)}")
                
                for symbol, position in real_positions.items():
                    if symbol not in self.open_positions:
                        print(f"📥 Добавляем пропущенную позицию: {symbol}")
                        self.open_positions[symbol] = {
                            'symbol': symbol,
                            'size': position['size'],
                            'entry_price': position['entry_price'],
                            'side': position['side'],
                            'leverage': position.get('leverage', 10),
                            'strategy': 'main',
                            'timestamp': datetime.now().isoformat(),
                            'position_value': position['size'] * position['entry_price'],
                        }
            
            print(f"✅ Синхронизировано позиций: {len(self.open_positions)}")
            
        except Exception as e:
            print(f"❌ Ошибка синхронизации с Binance: {e}")

    async def _print_initialization_summary(self, total_balance: float, balance_analysis: Dict):
        """Вывод итоговой информации"""
        active_positions = len(self.open_positions)
        market_analysis = self.market_analyzer.get_analysis()
        
        print('\n' + '='*60)
        print('🎯 ИНИЦИАЛИЗАЦИЯ ЗАВЕРШЕНА')
        print('='*60)
        print(f'💰 Общий баланс системы: ${total_balance:.2f}')
        print(f'🎯 Стратегия: {balance_analysis["tier"].upper()} уровень')
        print(f'📊 Максимум позиций: {balance_analysis["max_total_positions"]}')
        print(f'🛡️ Активных позиций: {active_positions}')
        print(f'📈 Режим рынка: {market_analysis["market_regime"].upper()}')
        print('='*60)

    async def run(self):
        """Основной цикл работы торговой системы"""
        print("🚀 Запуск основного цикла торговли...")
        self.is_running = True
        
        iteration = 0
        while self.is_running:
            try:
                iteration += 1
                print(f"\n🔄 Итерация #{iteration}")
                print("-" * 50)
                
                # 1. Обновляем баланс и маржу
                await self._update_balance_and_margin()
                
                # 2. Управляем открытыми позициями
                await self.position_manager.manage_open_positions(self.open_positions)
                
                # 3. Обновляем анализ рынка
                if iteration % 10 == 0:
                    await self.market_analyzer.analyze_market_conditions(self.dynamic_pairs)
                
                # 4. Сканируем новые возможности
                if self._can_open_new_positions():
                    await self._scan_and_execute_trades()
                
                # 5. Обновляем статистику
                await self.performance_tracker.update_stats(
                    self.open_positions, 
                    self.position_manager.get_closed_stats()
                )
                
                # 6. Проверяем условия для остановки
                await self._check_stop_conditions()
                
                # 7. Выводим статус
                await self._print_trading_status(iteration)
                
                await asyncio.sleep(10)
                
            except Exception as e:
                print(f"❌ Ошибка в основном цикле: {e}")
                await asyncio.sleep(5)

    async def _update_balance_and_margin(self):
        """Обновляет баланс и информацию о марже"""
        try:
            current_balance = await self.client.get_total_balance()
            self.performance_tracker.update_balance(current_balance)
            
            used_margin = sum(pos.get('position_value', 0) for pos in self.open_positions.values())
            free_margin = current_balance - used_margin
            
            self.performance_tracker.update_margin(used_margin, free_margin)
            
        except Exception as e:
            print(f"❌ Ошибка обновления баланса: {e}")

    def _can_open_new_positions(self) -> bool:
        """Проверяет можно ли открывать новые позиции"""
        active_positions = len(self.open_positions)
        free_margin = self.performance_tracker.get_free_margin()
        
        return active_positions < self.max_total_positions and free_margin > 10

    async def _scan_and_execute_trades(self):
        """Сканирует рынок и исполняет сделки"""
        try:
            signals = await self.technical_analyzer.analyze_multiple_pairs(self.dynamic_pairs)
            
            for signal in signals:
                if await self._validate_signal(signal):
                    await self._execute_trade(signal)
                    
        except Exception as e:
            print(f"❌ Ошибка сканирования сделок: {e}")

    async def _validate_signal(self, signal: Dict) -> bool:
        """Проверяет валидность торгового сигнала"""
        try:
            symbol = signal['symbol']
            
            if symbol in self.cooldown_periods:
                if datetime.now() < self.cooldown_periods[symbol]:
                    return False
            
            signal_quality = await self.signal_analyzer.analyze_signal_quality(signal)
            if signal_quality < 0.7:
                return False
            
            risk_assessment = await self.risk_manager.assess_trade_risk(signal)
            if not risk_assessment['approved']:
                return False
            
            return True
            
        except Exception as e:
            print(f"❌ Ошибка валидации сигнала: {e}")
            return False

    async def _execute_trade(self, signal: Dict):
        """Исполняет торговую сделку"""
        try:
            symbol = signal['symbol']
            side = signal['side']
            confidence = signal['confidence']
            
            position_size = await self._calculate_position_size(symbol, side, confidence)
            
            if position_size <= 0:
                return
            
            order = await self.client.create_order(
                symbol=symbol,
                type='market',
                side=side,
                amount=position_size
            )
            
            self.open_positions[symbol] = {
                'symbol': symbol,
                'size': position_size,
                'entry_price': signal['price'],
                'side': side,
                'leverage': self.SCALPING_CONFIG['leverage'],
                'strategy': 'scalping',
                'timestamp': datetime.now().isoformat(),
                'position_value': position_size * signal['price'],
                'stop_loss': signal.get('stop_loss', 2.0),
                'take_profit': signal.get('take_profit', 4.0)
            }
            
            print(f"🎯 ОТКРЫТА ПОЗИЦИЯ: {symbol} {side.upper()} ${position_size * signal['price']:.2f}")
            
            self.cooldown_periods[symbol] = datetime.now() + timedelta(minutes=5)
            await self.save_state()
            
        except Exception as e:
            print(f"❌ Ошибка исполнения сделки: {e}")

    async def _calculate_position_size(self, symbol: str, side: str, confidence: float) -> float:
        """Рассчитывает размер позиции"""
        try:
            free_margin = self.performance_tracker.get_free_margin()
            risk_amount = free_margin * self.risk_per_trade * confidence
            
            ticker = await self.client.fetch_ticker(symbol)
            current_price = ticker['last']
            
            position_size = risk_amount / current_price
            
            min_size = self.SCALPING_CONFIG['min_position_size'] / current_price
            max_size = self.SCALPING_CONFIG['max_position_size'] / current_price
            
            position_size = max(min_size, min(position_size, max_size))
            
            return position_size
            
        except Exception as e:
            print(f"❌ Ошибка расчета размера позиции: {e}")
            return 0

    async def _check_stop_conditions(self):
        """Проверяет условия для остановки торговли"""
        try:
            max_drawdown = self.performance_tracker.get_max_drawdown()
            if max_drawdown > 20:
                print(f"🛑 Достигнута максимальная просадка: {max_drawdown:.1f}%")
                self.is_running = False
                return
            
            profit_percentage = self.performance_tracker.get_profit_percentage()
            if profit_percentage > 50:
                print(f"🎯 Достигнута целевая прибыль: {profit_percentage:.1f}%")
                self.is_running = False
                return
                
        except Exception as e:
            print(f"❌ Ошибка проверки стоп-условий: {e}")

    async def _print_trading_status(self, iteration: int):
        """Выводит текущий статус торговли"""
        if iteration % 5 == 0:
            stats = self.performance_tracker.get_stats()
            closed_stats = self.position_manager.get_closed_stats()
            
            print(f"\n📊 СТАТУС ТОРГОВЛИ (#{iteration})")
            print("-" * 40)
            print(f"💰 Баланс: ${stats['current_balance']:.2f}")
            print(f"📈 Общий PnL: ${stats['total_pnl']:.2f}")
            print(f"🛡️  Позиций: {len(self.open_positions)}")
            print(f"🎯 Винрейт: {closed_stats.get('win_rate', 0):.1f}%")
            print(f"⏱️  Длительность: {stats['session_duration']}")
            print("-" * 40)

    async def save_state(self):
        """Сохраняет текущее состояние"""
        try:
            state = {
                'open_positions': self.open_positions,
                'trading_state': self.performance_tracker.get_trading_state(),
                'closed_positions_stats': self.position_manager.get_closed_stats(),
                'performance_metrics': self.performance_tracker.get_performance_metrics(),
                'market_analysis': self.market_analyzer.get_analysis(),
                'last_update': datetime.now().isoformat()
            }
            save_state(state)
        except Exception as e:
            print(f"❌ Ошибка сохранения состояния: {e}")

    async def safe_shutdown(self):
        """Безопасное завершение работы"""
        print("🛑 Безопасное завершение работы...")
        self.is_running = False
        
        if self.open_positions:
            close_positions = input("Закрыть все позиции перед выходом? (y/n): ").strip().lower()
            if close_positions == 'y':
                await self.position_manager.close_all_positions(self.open_positions)
        
        await self.save_state()
        self.performance_tracker.print_final_stats()
        print("✅ Система завершена")