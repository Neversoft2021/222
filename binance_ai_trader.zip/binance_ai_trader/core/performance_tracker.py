﻿from datetime import datetime
from typing import Dict


class PerformanceTracker:
    def __init__(self):
        self.trading_state = {
            'last_start': datetime.now().isoformat(),
            'total_trades': 0,
            'active_positions': 0,
            'scalping_pnl': 0,
            'main_pnl': 0,
            'total_pnl': 0,
            'balance': 0,
            'used_margin': 0,
            'free_margin': 0,
            'balance_tier': 'unknown',
            'session_start': datetime.now().isoformat(),
            'session_duration': '0:00:00',
            'hourly_rate': 0,
            'daily_projection': 0
        }
        
        self.performance_metrics = {
            'start_balance': 0,
            'current_balance': 0,
            'peak_balance': 0,
            'valley_balance': float('inf'),
            'max_drawdown': 0,
            'return_percentage': 0,
            'sharpe_ratio': 0,
            'calmar_ratio': 0,
            'volatility': 0,
            'trade_frequency': 0,
            'avg_trade_duration': 0
        }
        
        self.last_balance_print = None

    def initialize(self, start_balance: float):
        """Инициализация трекера производительности"""
        self.performance_metrics.update({
            'start_balance': start_balance,
            'current_balance': start_balance,
            'peak_balance': start_balance,
            'valley_balance': start_balance
        })
        
        self.trading_state.update({
            'balance': start_balance,
            'free_margin': start_balance
        })

    def update_balance(self, current_balance: float):
        """Обновляет баланс"""
        self.trading_state['balance'] = current_balance
        self.performance_metrics['current_balance'] = current_balance
        
        # Обновляем пиковый баланс
        if current_balance > self.performance_metrics['peak_balance']:
            self.performance_metrics['peak_balance'] = current_balance
        
        # Обновляем минимальный баланс
        if current_balance < self.performance_metrics['valley_balance']:
            self.performance_metrics['valley_balance'] = current_balance

    def update_margin(self, used_margin: float, free_margin: float):
        """Обновляет информацию о марже"""
        self.trading_state['used_margin'] = used_margin
        self.trading_state['free_margin'] = free_margin
        
        # Периодический вывод баланса
        if not self.last_balance_print or (datetime.now() - self.last_balance_print).seconds > 60:
            print(f"💰 Баланс: ${self.trading_state['balance']:.2f} | 🛡️ Использовано: ${used_margin:.2f} | 💎 Свободно: ${free_margin:.2f}")
            self.last_balance_print = datetime.now()

    def update_stats(self, open_positions: Dict, closed_stats: Dict):
        """Обновляет торговую статистику"""
        try:
            self.trading_state['active_positions'] = len(open_positions)
            self.trading_state['total_trades'] = closed_stats.get('total_closed', 0)
            
            # Расчет общего PnL
            total_profit = closed_stats.get('total_profit', 0)
            total_loss = closed_stats.get('total_loss', 0)
            self.trading_state['total_pnl'] = total_profit - total_loss
            
            # Обновляем метрики производительности
            self._update_performance_metrics()
            
        except Exception as e:
            print(f"❌ Ошибка обновления статистики: {e}")

    def _update_performance_metrics(self):
        """Обновляет метрики производительности"""
        try:
            current_balance = self.performance_metrics['current_balance']
            start_balance = self.performance_metrics['start_balance']
            peak_balance = self.performance_metrics['peak_balance']
            
            # Расчет доходности
            if start_balance > 0:
                self.performance_metrics['return_percentage'] = ((current_balance - start_balance) / start_balance) * 100
            
            # Расчет максимальной просадки
            if peak_balance > 0:
                drawdown = ((peak_balance - current_balance) / peak_balance) * 100
                self.performance_metrics['max_drawdown'] = max(self.performance_metrics['max_drawdown'], drawdown)
            
            # Обновляем длительность сессии
            session_start = datetime.fromisoformat(self.trading_state['session_start'])
            session_duration = datetime.now() - session_start
            self.trading_state['session_duration'] = str(session_duration).split('.')[0]
            
            # Расчет почасовой ставки
            hours = session_duration.total_seconds() / 3600
            if hours > 0:
                profit = current_balance - start_balance
                self.trading_state['hourly_rate'] = profit / hours
                self.trading_state['daily_projection'] = self.trading_state['hourly_rate'] * 24
                
        except Exception as e:
            print(f"❌ Ошибка обновления метрик: {e}")

    def get_free_margin(self) -> float:
        """Возвращает свободную маржу"""
        return self.trading_state.get('free_margin', 0)

    def get_max_drawdown(self) -> float:
        """Возвращает максимальную просадку"""
        return self.performance_metrics.get('max_drawdown', 0)

    def get_profit_percentage(self) -> float:
        """Возвращает процент прибыли"""
        return self.performance_metrics.get('return_percentage', 0)

    def get_stats(self) -> Dict:
        """Возвращает текущую статистику"""
        return {
            'current_balance': self.trading_state['balance'],
            'total_pnl': self.trading_state['total_pnl'],
            'session_duration': self.trading_state['session_duration']
        }

    def get_trading_state(self) -> Dict:
        """Возвращает состояние торговли"""
        return self.trading_state.copy()

    def get_performance_metrics(self) -> Dict:
        """Возвращает метрики производительности"""
        return self.performance_metrics.copy()

    def print_final_stats(self):
        """Выводит финальную статистику"""
        print("\n" + "="*60)
        print("📊 ФИНАЛЬНАЯ СТАТИСТИКА")
        print("="*60)
        print(f"💰 Начальный баланс: ${self.performance_metrics['start_balance']:.2f}")
        print(f"💰 Конечный баланс: ${self.trading_state['balance']:.2f}")
        print(f"📈 Общий PnL: ${self.trading_state['total_pnl']:.2f}")
        print(f"📉 Макс. просадка: {self.performance_metrics['max_drawdown']:.1f}%")
        print(f"⏱️  Длительность сессии: {self.trading_state['session_duration']}")
        print("="*60)