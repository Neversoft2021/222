﻿from typing import Dict


class MarginManager:
    def __init__(self):
        self.margin_cache = {}
        
    def calculate_available_margin(self, total_balance: float, used_margin: float, open_positions: Dict) -> float:
        total_used = used_margin
        
        for symbol, position in open_positions.items():
            position_size = position.get('size', 0)
            entry_price = position.get('entry_price', 0)
            leverage = position.get('leverage', 1)
            
            if position_size > 0 and entry_price > 0:
                position_value = position_size * entry_price
                position_margin = position_value / leverage
                total_used += position_margin
        
        available = total_balance - total_used
        return max(0, available)
    
    def calculate_position_margin(self, position_size_usdt: float, leverage: int) -> float:
        return position_size_usdt / leverage