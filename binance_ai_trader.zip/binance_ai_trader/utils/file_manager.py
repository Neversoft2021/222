﻿import os
import json
import aiofiles
from datetime import datetime
from config.settings import DATA_DIR

def cleanup_old_data():
    """Очистка старых тестовых данных"""
    try:
        print("🧹 Очистка данных...")
        
        if not os.path.exists(DATA_DIR):
            os.makedirs(DATA_DIR)
        
        # Создаем чистые файлы данных
        initial_state = {
            'open_positions': {},
            'trading_state': {
                'last_start': datetime.now().isoformat(),
                'total_trades': 0,
                'active_positions': 0,
                'balance': 0,
                'used_margin': 0,
                'free_margin': 0
            },
            'closed_positions_stats': {
                'total_closed': 0,
                'profitable_trades': 0,
                'unprofitable_trades': 0,
                'total_profit': 0.0,
                'total_loss': 0.0
            }
        }
        
        state_file = os.path.join(DATA_DIR, 'trading_state.json')
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(initial_state, f, indent=2, ensure_ascii=False)
        
        print("✅ Созданы чистые файлы данных")
        
    except Exception as e:
        print(f"❌ Ошибка очистки данных: {e}")

def save_state(state_data):
    """Синхронное сохранение состояния"""
    try:
        state_file = os.path.join(DATA_DIR, 'trading_state.json')
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(state_data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"❌ Ошибка сохранения состояния: {e}")
        return False

def load_state():
    """Синхронная загрузка состояния"""
    try:
        state_file = os.path.join(DATA_DIR, 'trading_state.json')
        if os.path.exists(state_file):
            with open(state_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return None
    except Exception as e:
        print(f"❌ Ошибка загрузки состояния: {e}")
        return None

# Асинхронные версии (если нужны)
async def save_state_async(state_data):
    """Асинхронное сохранение состояния"""
    try:
        state_file = os.path.join(DATA_DIR, 'trading_state.json')
        async with aiofiles.open(state_file, 'w', encoding='utf-8') as f:
            await f.write(json.dumps(state_data, indent=2, ensure_ascii=False))
        return True
    except Exception as e:
        print(f"❌ Ошибка сохранения состояния: {e}")
        return False

async def load_state_async():
    """Асинхронная загрузка состояния"""
    try:
        state_file = os.path.join(DATA_DIR, 'trading_state.json')
        if os.path.exists(state_file):
            async with aiofiles.open(state_file, 'r', encoding='utf-8') as f:
                content = await f.read()
                return json.loads(content)
        return None
    except Exception as e:
        print(f"❌ Ошибка загрузки состояния: {e}")
        return None