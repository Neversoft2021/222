﻿# Utility functions
