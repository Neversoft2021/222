﻿import os
from dotenv import load_dotenv

load_dotenv()

# API Keys
API_KEY = os.getenv('BINANCE_API_KEY', 'your_api_key_here')
SECRET_KEY = os.getenv('BINANCE_SECRET_KEY', 'your_secret_key_here')

# Minerva DYOR Settings
DYOR_EMAIL = os.getenv('DYOR_EMAIL', 'your_email@example.com')
DYOR_PASSWORD = os.getenv('DYOR_PASSWORD', 'your_password_here')

# Trading Settings
RISK_PER_TRADE = 0.02  # 2% risk per trade
MAX_DRAWDOWN = 0.1     # 10% max drawdown

# Data Settings
DATA_DIR = 'data'

# Scalping Pairs
SCALPING_PAIRS = [
    'ETH/USDT:USDT', 'BNB/USDT:USDT', 'SOL/USDT:USDT', 'LTC/USDT:USDT',
    'DOGE/USDT:USDT', 'ENA/USDT:USDT', 'AVAX/USDT:USDT', 'LINK/USDT:USDT',
    'UNI/USDT:USDT', 'TRUMP/USDT:USDT', 'APT/USDT:USDT', 'ICP/USDT:USDT',
    'ONDO/USDT:USDT', 'ONT/USDT:USDT', 'METIS/USDT:USDT', 'BAS/USDT:USDT',
    'COAI/USDT:USDT', 'PUMP/USDT:USDT', 'USELESS/USDT:USDT', 'XPL/USDT:USDT',
    'ASTER/USDT:USDT', 'HYPE/USDT:USDT'
]

# Timeframes
TIMEFRAMES = ['1m', '5m', '15m', '1h', '4h']

# Minerva Settings
MINERVA_ENABLED = True
MINERVA_TIMEOUT = 30

# Logging
LOG_LEVEL = 'INFO'

# Risk Management
MAX_LEVERAGE = 25
MAX_POSITION_SIZE = 0.1  # 10% of balance per position
STOP_LOSS_PERCENT = 2.0
TAKE_PROFIT_PERCENT = 4.0

# Trading Hours (UTC)
TRADING_HOURS_START = 0   # 00:00 UTC
TRADING_HOURS_END = 24    # 24:00 UTC (all day)

# Cooldown Settings
COOLDOWN_AFTER_LOSS = 300  # 5 minutes cooldown after loss
COOLDOWN_AFTER_WIN = 60    # 1 minute cooldown after win

# Performance Targets
DAILY_PROFIT_TARGET = 0.05  # 5% daily target
MAX_DAILY_LOSS = 0.03       # 3% max daily loss

# Technical Analysis Settings
RSI_OVERBOUGHT = 70
RSI_OVERSOLD = 30
MACD_FAST = 12
MACD_SLOW = 26
MACD_SIGNAL = 9

# Market Conditions
VOLATILITY_THRESHOLD_HIGH = 3.0
VOLATILITY_THRESHOLD_LOW = 1.0
TREND_STRENGTH_THRESHOLD = 0.7

# Notification Settings
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '')
TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID', '')

# Database Settings
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///trading_data.db')

# Backup Settings
BACKUP_ENABLED = True
BACKUP_INTERVAL = 3600  # 1 hour in seconds

# Debug Settings
DEBUG_MODE = False
VERBOSE_LOGGING = True