﻿import ccxt
import asyncio
from typing import Dict, List, Optional
from decimal import Decimal
import logging

logger = logging.getLogger(__name__)

class BinanceClient:
    def __init__(self, api_key: str, secret_key: str):
        self.api_key = api_key
        self.secret_key = secret_key
        self.exchange = None
        self.is_initialized = False
        
    async def initialize(self):
        """Инициализация подключения к Binance"""
        try:
            print("🔧 Инициализируем подключение к Binance...")
            
            self.exchange = ccxt.binance({
                'apiKey': self.api_key,
                'secret': self.secret_key,
                'sandbox': False,
                'enableRateLimit': True,
                'options': {
                    'defaultType': 'future',
                },
                'timeout': 30000,
                'rateLimit': 1000,
            })
            
            # Проверяем подключение простым запросом
            print("   🔄 Проверяем подключение к Binance...")
            markets = self.exchange.load_markets()
            
            if not markets:
                print("   ❌ Не удалось загрузить рынки")
                return False
            
            print(f"   ✅ Загружено рынков: {len(markets)}")
            
            # Пробуем установить позиционирование (не критично если не получится)
            try:
                self.exchange.futures_change_position_mode({'dualSidePosition': False})
                print("   ✅ Режим позиционирования установлен")
            except Exception as e:
                if 'No need to change position side' in str(e):
                    print("   ⚠️ Позиции: режим уже установлен")
                else:
                    print(f"   ⚠️ Позиции: {e}")
            
            self.is_initialized = True
            print("   ✅ Binance инициализирован успешно")
            return True
            
        except ccxt.NetworkError as e:
            print(f"❌ Ошибка сети Binance: {e}")
            return False
        except ccxt.ExchangeError as e:
            print(f"❌ Ошибка биржи Binance: {e}")
            return False
        except Exception as e:
            print(f"❌ Общая ошибка инициализации Binance: {e}")
            return False

    def load_markets(self):
        """Загружает информацию о рынках (синхронный метод)"""
        try:
            if self.exchange:
                return self.exchange.load_markets()
            return {}
        except Exception as e:
            print(f"❌ Ошибка загрузки рынков: {e}")
            return {}

    async def get_total_balance(self):
        """Получает общий баланс в USDT"""
        try:
            if not self.exchange:
                return 0
                
            # Получаем баланс фьючерсного счета
            balance = self.exchange.fetch_balance({'type': 'future'})
            
            total_balance = 0
            print("🔍 Анализируем реальные доступные средства:")
            
            # Суммируем доступные средства в стейблкоинах
            stablecoins = ['USDT', 'USDC', 'BUSD', 'DAI']
            for currency, amount in balance['total'].items():
                if currency in stablecoins and amount > 0:
                    free_amount = balance['free'].get(currency, 0)
                    print(f"   ✅ {currency}: {free_amount}")
                    if currency == 'USDT':
                        total_balance += free_amount
                    else:
                        # Конвертируем другие стейблкоины в USDT
                        try:
                            ticker = self.exchange.fetch_ticker(f'{currency}/USDT')
                            total_balance += free_amount * ticker['last']
                        except:
                            total_balance += free_amount  # предполагаем 1:1
            
            # Проверяем availableBalance из API
            available_balance = balance.get('info', {}).get('availableBalance', 0)
            if available_balance:
                available_balance = float(available_balance)
                print(f"   ✅ Available Balance из API: {available_balance}")
                print(f"   🔄 Используем availableBalance: ${available_balance:.2f}")
                return available_balance
            else:
                print(f"   🔄 Используем расчетный баланс: ${total_balance:.2f}")
                return total_balance
                
        except Exception as e:
            print(f"❌ Ошибка получения баланса: {e}")
            return 0

    async def fetch_ticker(self, symbol: str) -> Dict:
        """Получает текущие данные по тикеру"""
        try:
            if not self.exchange:
                raise Exception("Exchange not initialized")
            return self.exchange.fetch_ticker(symbol)
        except Exception as e:
            print(f"❌ Ошибка получения тикера {symbol}: {e}")
            return {'last': 0, 'bid': 0, 'ask': 0}

    async def create_order(self, symbol: str, type: str, side: str, amount: float, price: Optional[float] = None):
        """Создает ордер"""
        try:
            if not self.exchange:
                raise Exception("Exchange not initialized")
                
            order_params = {
                'symbol': symbol,
                'type': type,
                'side': side,
                'amount': amount,
            }
            
            if price:
                order_params['price'] = price
                
            return self.exchange.create_order(**order_params)
            
        except Exception as e:
            print(f"❌ Ошибка создания ордера {symbol}: {e}")
            raise

    async def cancel_order(self, symbol: str, order_id: str):
        """Отменяет ордер"""
        try:
            if not self.exchange:
                raise Exception("Exchange not initialized")
            return self.exchange.cancel_order(order_id, symbol)
        except Exception as e:
            print(f"❌ Ошибка отмены ордера {order_id}: {e}")
            raise

    async def fetch_open_orders(self, symbol: str = None):
        """Получает открытые ордера"""
        try:
            if not self.exchange:
                raise Exception("Exchange not initialized")
                
            if symbol:
                return self.exchange.fetch_open_orders(symbol)
            else:
                return self.exchange.fetch_open_orders()
                
        except Exception as e:
            print(f"❌ Ошибка получения открытых ордеров: {e}")
            return []

    async def fetch_balance(self):
        """Получает баланс"""
        try:
            if not self.exchange:
                raise Exception("Exchange not initialized")
            return self.exchange.fetch_balance({'type': 'future'})
        except Exception as e:
            print(f"❌ Ошибка получения баланса: {e}")
            return {}

    async def get_open_positions(self):
        """Получает открытые позиции с Binance Futures"""
        try:
            print("🔍 Загружаем открытые позиции с Binance...")
            
            if not self.exchange:
                print("❌ Exchange не инициализирован")
                return {}
            
            # Получаем информацию о счете фьючерсов
            account_info = self.exchange.futures_account()
            positions = account_info['positions']
            
            open_positions = {}
            for pos in positions:
                position_amount = float(pos['positionAmt'])
                
                # Если есть открытая позиция (не нулевая)
                if position_amount != 0:
                    symbol = pos['symbol']
                    open_positions[symbol] = {
                        'symbol': symbol,
                        'size': abs(position_amount),
                        'entry_price': float(pos['entryPrice']),
                        'side': 'long' if position_amount > 0 else 'short',
                        'leverage': int(pos['leverage']),
                        'unrealized_pnl': float(pos['unRealizedProfit']),
                        'liquidation_price': float(pos['liquidationPrice']),
                        'margin_type': pos['marginType'],
                        'isolated_wallet': float(pos.get('isolatedWallet', 0))
                    }
                    print(f"   ✅ Найдена позиция: {symbol} {position_amount}")
            
            print(f"📊 Всего открытых позиций на Binance: {len(open_positions)}")
            return open_positions
            
        except Exception as e:
            print(f"❌ Ошибка загрузки позиций с Binance: {e}")
            return {}

    async def set_leverage(self, symbol: str, leverage: int):
        """Устанавливает плечо для символа"""
        try:
            if not self.exchange:
                raise Exception("Exchange not initialized")
                
            return self.exchange.set_leverage(leverage, symbol)
            
        except Exception as e:
            print(f"❌ Ошибка установки плеча для {symbol}: {e}")
            raise

    async def set_margin_mode(self, symbol: str, margin_mode: str):
        """Устанавливает режим маржи (isolated/cross)"""
        try:
            if not self.exchange:
                raise Exception("Exchange not initialized")
                
            return self.exchange.set_margin_mode(margin_mode, symbol)
            
        except Exception as e:
            print(f"❌ Ошибка установки режима маржи для {symbol}: {e}")
            raise

    async def fetch_ohlcv(self, symbol: str, timeframe: str = '1m', limit: int = 100):
        """Получает OHLCV данные"""
        try:
            if not self.exchange:
                raise Exception("Exchange not initialized")
                
            return self.exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
            
        except Exception as e:
            print(f"❌ Ошибка получения OHLCV для {symbol}: {e}")
            return []

    async def fetch_order_book(self, symbol: str, limit: int = 20):
        """Получает стакан ордеров"""
        try:
            if not self.exchange:
                raise Exception("Exchange not initialized")
                
            return self.exchange.fetch_order_book(symbol, limit)
            
        except Exception as e:
            print(f"❌ Ошибка получения стакана для {symbol}: {e}")
            return {'bids': [], 'asks': []}

    def futures_account(self):
        """Получает информацию о фьючерсном счете (синхронный метод)"""
        try:
            if not self.exchange:
                raise Exception("Exchange not initialized")
            return self.exchange.futures_account()
        except Exception as e:
            print(f"❌ Ошибка получения фьючерсного счета: {e}")
            return {}

    async def close(self):
        """Закрывает соединение"""
        try:
            if self.exchange:
                await self.exchange.close()
        except Exception as e:
            print(f"❌ Ошибка закрытия соединения: {e}")