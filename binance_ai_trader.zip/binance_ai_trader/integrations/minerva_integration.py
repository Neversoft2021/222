﻿import asyncio
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
from typing import List, Dict
from datetime import datetime, timedelta

from config.settings import DYOR_EMAIL, DYOR_PASSWORD
from analysis.technical_analyzer import AdvancedTechnicalAnalyzer
from analysis.signal_analyzer import SignalQualityAnalyzer


class RealMinervaIntegration:
    def __init__(self, trading_bot):
        self.trading_bot = trading_bot
        self.dyor_email = DYOR_EMAIL
        self.dyor_password = DYOR_PASSWORD
        self.is_running = False
        self.driver = None
        self.technical_analyzer = AdvancedTechnicalAnalyzer()
        self.signal_analyzer = SignalQualityAnalyzer()
        self.last_check_time = None
        self.signal_history = {}  # История сигналов по активам
    
    async def initialize(self):
        print("🚀 Инициализация Minerva...")
        try:
            chrome_options = Options()
            chrome_options.add_argument("--headless")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--window-size=1920,1080")
            
            # 🔇 ОТКЛЮЧАЕМ ВСЕ ЛОГИ CHROME
            chrome_options.add_argument("--log-level=3")
            chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])
            chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            
            # Используем ChromeDriverManager из webdriver_manager
            from webdriver_manager.chrome import ChromeDriverManager
            service = Service(ChromeDriverManager().install())
            
            # 🔇 Отключаем логи сервиса
            service.creationflags = 0x08000000  # CREATE_NO_WINDOW
            
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            
            # 🔇 Отключаем логи браузера
            self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
            
            await self._login_once()
            print("✅ Minerva готова")
            return True
            
        except Exception as e:
            print(f"❌ Ошибка Minerva: {e}")
            return False
    
    async def _login_once(self):
        try:
            print("🔐 Авторизация DYOR...")
            self.driver.get("https://ru.dyorplatform.com/login")
            await asyncio.sleep(5)
            
            email_field = self.driver.find_element(By.XPATH, "//input[@placeholder='Введите ваш логин']")
            email_field.clear()
            email_field.send_keys(self.dyor_email)
            await asyncio.sleep(1)
            
            password_field = self.driver.find_element(By.XPATH, "//input[@placeholder='Введите ваш пароль']")
            password_field.clear()
            password_field.send_keys(self.dyor_password)
            await asyncio.sleep(1)
            
            login_button = self.driver.find_element(By.XPATH, "//button[contains(., 'Войти')]")
            self.driver.execute_script("arguments[0].click();", login_button)
            await asyncio.sleep(8)
            
            print("✅ Авторизация успешна")
            
        except Exception as e:
            print(f"❌ Ошибка авторизации: {e}")
            raise
    
    async def get_fresh_signals(self) -> List[Dict]:
        try:
            print("⚡ Парсим САМЫЕ НАДЕЖНЫЕ сигналы Minerva...")
            
            self.driver.get("https://ru.dyorplatform.com/screenerMinerva/")
            await asyncio.sleep(3)
            
            # Всегда выбираем 5 минутный таймфрейм
            five_min_button = self.driver.find_element(By.XPATH, "//label[@for='source-5m']")
            self.driver.execute_script("arguments[0].click();", five_min_button)
            await asyncio.sleep(3)
            
            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            table = soup.find('table', {'id': 'depths-table'})
            
            if not table:
                return []
            
            signals = []
            tbody = table.find('tbody')
            current_time = datetime.now()
            
            if tbody:
                rows = tbody.find_all('tr')
                print(f"📊 Найдено строк: {len(rows)}")
                
                for row in rows:
                    try:
                        signal = self._parse_reliable_signals_only(row, current_time)
                        if signal:
                            signals.append(signal)
                    except:
                        continue
            
            print(f"✅ НАДЕЖНЫХ сигналов (1.5>15/30): {len(signals)}")
            return signals
            
        except Exception as e:
            print(f"❌ Ошибка парсинга: {e}")
            return []
    
    def _parse_reliable_signals_only(self, row, current_time: datetime) -> Dict:
        """
        Парсим ТОЛЬКО самые надежные сигналы по рекомендации разработчика:
        - 1.5>15 (самые надежные)
        - 1.5>30 (надежные)
        - Только FRESH
        - Только N=1
        - Не старше 30 минут
        """
        try:
            cells = row.find_all('td')
            if len(cells) < 8:
                return None
            
            ticker = cells[1].get_text().strip().replace('#', '')
            order_type = cells[2].get_text().strip().lower()
            trend = cells[6].get_text().strip() if len(cells) > 6 else 'TREND'
            n_value = cells[7].get_text().strip() if len(cells) > 7 else '1'
            
            # 🔥 ФИЛЬТР 1: ТОЛЬКО ФРЕШ СИГНАЛЫ (FRESH)
            if trend != 'FRESH':
                return None
            
            # 🔥 ФИЛЬТР 2: ТОЛЬКО N=1 (самые свежие)
            if n_value != '1':
                return None
            
            # 🔥 ФИЛЬТР 3: ТОЛЬКО САМЫЕ НАДЕЖНЫЕ СИГНАЛЫ (1.5>15 и 1.5>30)
            is_reliable_signal = False
            action = None
            signal_type = None
            direction_emoji = None
            
            # Проверяем сигналы покупки (b1.5 > a15, b1.5 > a30)
            if 'b1.5 > a15' in order_type or 'b1.5 > a30' in order_type:
                action = 'BUY'
                signal_type = 'P'
                direction_emoji = '🟢'
                is_reliable_signal = True
                print(f"🎯 НАДЕЖНЫЙ СИГНАЛ ПОКУПКИ: {ticker} - {order_type}")
            
            # Проверяем сигналы продажи (a1.5 > b15, a1.5 > b30)  
            elif 'a1.5 > b15' in order_type or 'a1.5 > b30' in order_type:
                action = 'SELL'
                signal_type = 'N'
                direction_emoji = '🔴'
                is_reliable_signal = True
                print(f"🎯 НАДЕЖНЫЙ СИГНАЛ ПРОДАЖИ: {ticker} - {order_type}")
            
            if not is_reliable_signal:
                return None
            
            # Определяем силу сигнала на основе типа
            signal_strength = self._get_reliable_strength(order_type)
            
            # 🔥 ФИЛЬТР 4: ПРОВЕРКА ВРЕМЕНИ (не старше 30 минут)
            signal_time = current_time
            
            # Если есть колонка со временем
            if len(cells) > 8:
                time_str = cells[8].get_text().strip()
                try:
                    if ':' in time_str:
                        signal_time = self._parse_time_string(time_str, current_time)
                except:
                    pass
            
            # Проверяем что сигнал не старше 30 минут
            time_diff = current_time - signal_time
            if time_diff.total_seconds() > 1800:  # 30 минут в секундах
                return None
            
            # Сохраняем в историю для отслеживания повторных сигналов
            self._update_signal_history(ticker, order_type, signal_time, current_price=None)
            
            return {
                'ticker': ticker,
                'signal_type': f"{signal_strength}{signal_type}",
                'action': action,
                'order_type': order_type,  # Сохраняем оригинальный тип ордера
                'trend_type': trend,
                'n_value': n_value,
                'source': 'minerva',
                'direction_emoji': direction_emoji,
                'is_fresh_signal': True,
                'is_reliable_signal': True,
                'signal_time': signal_time.isoformat(),
                'time_diff_minutes': int(time_diff.total_seconds() / 60),
                'reliability_score': self._calculate_reliability_score(order_type, ticker)
            }
            
        except Exception as e:
            print(f"⚠️ Ошибка парсинга строки: {e}")
            return None
    
    def _get_reliable_strength(self, order_type: str) -> str:
        """Определяем силу для надежных сигналов"""
        if '1.5 > 15' in order_type:
            return '6'  # Максимальная надежность
        elif '1.5 > 30' in order_type:
            return '5'  # Высокая надежность
        else:
            return '4'  # Базовая надежность
    
    def _calculate_reliability_score(self, order_type: str, ticker: str) -> float:
        """Рассчитываем score надежности сигнала"""
        base_score = 0.8  # Базовый score для надежных сигналов
        
        # Повышаем score для более агрессивных сигналов
        if '1.5 > 15' in order_type:
            base_score += 0.15
        elif '1.5 > 30' in order_type:
            base_score += 0.1
        
        # Проверяем историю сигналов по этому тикеру
        if ticker in self.signal_history:
            recent_signals = [
                s for s in self.signal_history[ticker] 
                if (datetime.now() - s['time']).total_seconds() < 3600  # За последний час
            ]
            if len(recent_signals) > 0:
                base_score += 0.05  # Повторный сигнал - повышаем надежность
        
        return min(0.95, base_score)
    
    def _update_signal_history(self, ticker: str, order_type: str, time: datetime, current_price: float = None):
        """Обновляем историю сигналов"""
        if ticker not in self.signal_history:
            self.signal_history[ticker] = []
        
        self.signal_history[ticker].append({
            'order_type': order_type,
            'time': time,
            'price': current_price
        })
        
        # Очищаем старые записи (старше 24 часов)
        self.signal_history[ticker] = [
            s for s in self.signal_history[ticker] 
            if (datetime.now() - s['time']).total_seconds() < 86400
        ]
    
    def _parse_time_string(self, time_str: str, current_time: datetime) -> datetime:
        """Парсит строку времени из Minerva"""
        try:
            if ':' in time_str:
                hours, minutes = map(int, time_str.split(':'))
                signal_time = current_time.replace(hour=hours, minute=minutes, second=0, microsecond=0)
                
                if signal_time > current_time:
                    signal_time = signal_time - timedelta(days=1)
                
                return signal_time
        except:
            pass
        
        return current_time

    async def start_monitoring(self, interval: int = 1200):  # 20 минут
        self.is_running = True
        print(f"🔍 Мониторинг Minerva (интервал: {interval} сек = 20 минут)")
        
        print("🎯 Первая проверка надежных сигналов...")
        await self._process_minerva_signals()
        
        iteration = 0
        while self.is_running:
            try:
                iteration += 1
                print(f"\n🕒 Minerva проверка #{iteration} (каждые 20 минут)")
                await self._process_minerva_signals()
                
                print(f"💤 Ожидание 20 минут...")
                for i in range(interval):
                    if not self.is_running:
                        break
                    await asyncio.sleep(1)
                
            except Exception as e:
                print(f"❌ Ошибка мониторинга: {e}")
                await asyncio.sleep(30)

    async def _process_minerva_signals(self):
        """Обработка ТОЛЬКО надежных сигналов"""
        current_time = datetime.now()
        
        if self.last_check_time:
            time_since_last_check = current_time - self.last_check_time
            if time_since_last_check.total_seconds() < 600:  # 10 минут минимум
                print(f"⏰ Следующая проверка через {int((600 - time_since_last_check.total_seconds()) / 60)} мин")
                return
        
        self.last_check_time = current_time
        
        signals = await self.get_fresh_signals()
        if signals:
            # Фильтруем самые свежие (последние 15 минут)
            very_fresh_signals = [
                s for s in signals 
                if s.get('time_diff_minutes', 60) <= 15
            ]
            
            if very_fresh_signals:
                print(f"🔥 ОЧЕНЬ НАДЕЖНЫХ сигналов (≤15min): {len(very_fresh_signals)}")
                for signal in very_fresh_signals:
                    print(f"   🎯 {signal['ticker']} - {signal['order_type']} - {signal['reliability_score']:.2f}")
                
                await self.trading_bot.process_fresh_signals(very_fresh_signals)
            else:
                print("📭 Нет очень свежих надежных сигналов")
        else:
            print("📭 Нет надежных сигналов (1.5>15/30)")
    
    async def close_session(self):
        if self.driver:
            self.driver.quit()
            print("✅ Сессия Minerva закрыта")